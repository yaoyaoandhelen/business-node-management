# 映射式导入

`project init` 默认创建空白业务项目；需要客户演示时显式使用 `--template customer-demo`。既有原型使用 `project import`，不会自动选择源工作台的客户示例或 latest-review。

```sh
node workflow-kit/bin/pwf.mjs project import --source <源根目录> --directory projects/<新目录> --id <新projectId> --name <名称> --mapping <映射.json> --dry-run
```

核对计划后去掉 `--dry-run` 执行。预演完全只读，不创建目标或缓存。映射文件支持 JSON/YAML；文件位置相对运行命令的 cwd，映射内所有 `source` 均相对 `--source` 根。

```json
{
  "schemaVersion": 1,
  "prototype": {
    "source": "studio/apps/business",
    "adapter": "vite",
    "config": "vite.config.mjs",
    "output": "dist"
  },
  "pages": [{"id":"home","name":"首页","path":"./index.html"}],
  "requirements": "studio/data/requirements/regional-node.json",
  "supportingFiles": [{"source":"docs","target":"inputs/legacy-docs"}],
  "legacyReviews": [{"source":"studio/data/reviews/OLD_REVIEW_ID","target":"OLD_REVIEW_ID"}]
}
```

`prototype.config/output` 相对选定原型根；导入后根固定为 `prototype/`。静态原型使用 `adapter: static`，source 直接指向可静态托管的目录，省略 config；output 省略或设为 `.`。不会将所有原型强制转换为 Vite。页面 ID 必须覆盖原需求绑定，页面路径相对原型根；不能猜测或静默改变原绑定。

支持资料的 target 只能位于 `inputs/`；旧评审写入 `inputs/legacy-reviews/<标识>/`，原身份、JSON和资源字节保持不变，不进入新项目 live reviews 或批准状态。需要哪些旧版本必须逐一显式列出。

复制会排除 node_modules、Git 元数据、本机缓存、Agent/编辑器配置、.env 与 credentials.json，并在计划中登记。显式选择凭据路径、目录越界、未处理符号链接、重复目标及缺失入口会直接失败。源和目标不能互相包含；非空目标或重复 projectId 不覆盖。文件在临时项目组装并复核源摘要后才提交。

新项目必须使用不同 projectId；原需求 JSON 完整字节备份位于 `inputs/imported/requirements.original.json`，当前需求升为兼容 schema 并保留 reqId、模块、绑定、revision及扩展字段。无法校验的旧内容会明确报错；不会编造验收场景，正式评审缺项保存在导入计划。

导入会配置独立工具归档、恢复入口和受管理 Skill 链接，不带入旧远程目标、浏览器会话或凭据。检查 Inspector 顺序/可信来源、构建配置中的外部引用和业务依赖后，实际启动并验证；命令成功只代表资料已安全导入，不代表原型已运行、上线、批准或交接。

`project check` 的 `valid` 仅说明配置与需求结构可读；`runtimeReady` 和 `needsAttention` 另行报告本地依赖、页面、Inspector顺序/版本及来源配置。`runtimeVerified` 保持 false，因为只读检查没有启动浏览器或服务。缺少接入代码的原型会明确标记待适配；导入器不自动重写未知业务脚本。

若仅迁出一个已配置项目并保持原身份，不使用 import：保留原项目与 tooling 归档/锁，按对应版本恢复流程处理。
