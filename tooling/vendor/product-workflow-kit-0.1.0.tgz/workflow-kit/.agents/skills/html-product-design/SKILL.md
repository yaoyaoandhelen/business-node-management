---
name: html-product-design
description: 为业务项目设计或修改可交互HTML原型，接入独立AI Prototype Studio，维护功能说明并处理原型评审意见。适用于Web原型设计，不用于生产系统实现。
---

读取本项目配置、需求 JSON、分析记录和既有原型；目标与范围不明时先补产品规则。共用规范见 [工作台接入](../../../docs/studio.md)。

规则仅编辑 `data/requirements/<projectId>.json`。按业务模块和子模块组织目录，字段集中到字段表；查询/表单写清类型、默认值、必填与校验，统计写清口径、范围和刷新时机。补充必要的正常、空、异常、权限和验收场景，不编造业务决定。

保持现有技术栈和界面体系。复用固定 Studio 运行时；工作台 UI 与业务组件分离。业务入口之前加载 Inspector，使用稳定 `data-req-id`、`data-req-element`，允许来源必须精确登记。

```sh
node tooling/run.mjs requirements validate --project project.config.yaml
node tooling/run.mjs studio dev --project project.config.yaml
node tooling/run.mjs requirements project --project project.config.yaml
```

浏览器验证完整页面默认展示、按钮进入需求空间、选中元素定位模块、编辑保存到真实 JSON、刷新恢复。切换空间复用同一 iframe；需求空间的鼠标、键盘与提交不得执行业务，预览保持原交互。

处理评审时记录意见和结论，改动回到需求源及原型。不得直接手改生成规格来另建规则源。生成交付快照转 `github-pages-review`；已交接范围变化转 `zentao-handoff` 形成影响清单。

交付本机可访问统一入口与实际验证结果；未经部署不可称为远程团队地址。不要修改工作台上游目录或覆盖其他项目需求。
