---
name: html-product-design
description: 为业务项目设计或修改可交互HTML原型，接入独立AI Prototype Studio，维护功能说明并处理原型评审意见。适用于Web原型设计，不用于生产系统实现。
---

先读 [Agent 协议](../../../docs/agent-protocol.md)、[工作流的原型约束](../../../docs/workflow.md#web-原型的共同约束) 和 [Studio 接入](../../../docs/studio.md)。使用本项目锁定的说明；普通文件可直接读取，无需原生 Skill 注册。

读取项目 AGENTS、配置、工具锁、需求 JSON、分析、既有原型和有效上下文。0.2 支持时用 `workflow context --intent prototype`；版本和命令核验见 [手册](../../../docs/user-guide.md)。目标不清先补规则，声明本轮业务文件范围，不默认修改公共工具。

保持现有技术栈和界面体系。功能规则只在项目 JSON 编辑，模块/子模块组织及字段表、统计口径遵守共享工作流。补充真实正常、空、异常、权限和验收场景，未决业务决定明确保留，不由生成器编造。

默认接入独立 Studio，工作台 UI 与业务组件分离；Inspector 在业务入口前初始化，稳定语义锚点和精确可信来源齐备。需求编辑与预览共用 iframe，保存经文件服务真实落盘。详细要求以共享规范为准，不能因既有页面来自其他项目而省略或覆盖原需求。

业务项目根命令：

```sh
node tooling/run.mjs requirements validate --project project.config.yaml
node tooling/run.mjs studio dev --project project.config.yaml
node tooling/run.mjs requirements project --project project.config.yaml --change CHANGE_ID
```

实际验证默认完整页面、按钮进入需求空间、选择定位模块、按需编辑、JSON 保存、刷新恢复、鼠标/键盘/提交拦截与预览恢复，记录运行结果和统一入口。启动失败或工作台不可用时先定位/恢复，如实报告；本机地址不能冒称远程团队地址。

评审改动回到原型和唯一需求源，保留意见及处理结论；不要直接手改生成规格另建正文。交付快照读取 [github-pages-review](../github-pages-review/SKILL.md)；已交接范围变化读取 [zentao-handoff](../zentao-handoff/SKILL.md)。跨会话工作按协议保存任务交接与实际检查，不推定批准或实现。
