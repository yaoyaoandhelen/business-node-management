import {defineConfig} from 'vite';
import vue from '@vitejs/plugin-vue';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url));
const context=JSON.parse(readFileSync(fileURLToPath(new URL('../../.runtime.json',import.meta.url)),'utf8'));
export default defineConfig({base:'./',root,cacheDir:fileURLToPath(new URL('../../.vite-cache',import.meta.url)),plugins:[vue(),{name:'registered-prototype-origin',configureServer(server){server.middlewares.use((req,res,next)=>{res.setHeader('Content-Security-Policy',`frame-src ${context.origins.prototype}; object-src 'none'`);next()})}}],server:{host:'127.0.0.1',port:context.ports.studio,strictPort:true,fs:{allow:[fileURLToPath(new URL('../..',import.meta.url))]},proxy:{'/api':context.origins.api,'/inspector.js':context.origins.api,'/review':context.origins.api,'/preview':context.origins.api}},build:{outDir:'dist',emptyOutDir:true}});
