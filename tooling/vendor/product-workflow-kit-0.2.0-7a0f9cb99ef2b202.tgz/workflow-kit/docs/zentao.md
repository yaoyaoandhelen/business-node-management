# 禅道交接与研发协同

交接使用批准时冻结的需求 JSON，不读取较新的工作草稿。先生成 JSON 计划，核对业务拆分、固定评审地址和接收人，再执行用户已授权的同步。建议任务不含产品猜测的研发工时；默认每个非字段功能生成故事，技术拆分由研发确认。

```sh
node bin/pwf.mjs zentao plan --project /absolute/project/project.config.yaml --review REVIEW_ID
```

CLI 的具体同步参数以 `node bin/pwf.mjs help` 为准。Node API 为确定性入口：

```js
import { createHandoffPlan, syncHandoff, reconcileHandoff, createMemoryAdapter } from '../adapters/zentao/index.mjs';
const plan = await createHandoffPlan(ctx, { reviewId });
const preview = await syncHandoff(ctx, plan); // 默认只预演，不写远端
const simulation = createMemoryAdapter();
await syncHandoff(ctx, plan, { adapter: simulation, allowWrite: true });
```

模拟结果标记 `simulated`，只写 `delivery/zentao/simulation/`，不会标记真实已发送、已指派、已接收或已验收。生成计划与模拟测试均不要求提供真实凭据。没有批准基线时，`createHandoffPlan(ctx,{draft:true})` 只生成明确标记的草案；草案不能同步。

## 配置与连接

默认 `zentao.provider: mcp`。工具箱使用官方 `@modelcontextprotocol/sdk` 1.32.2 接入明确配置的禅道 MCP 服务；本机认证与真实只读验证状态见 [验证记录](verification.md)。SDK 验证与当前聊天是否已加载原生工具分别记录。网站地址 `baseUrl` 与 MCP 端点分别配置，例如 `http://host:16515` 是网站根地址，不能据此猜测 MCP 路径，也不能填 `program-browse.html` 页面地址作为 MCP 端点。工具箱不会回退网页操作或 REST。

MCP 可使用 Streamable HTTP 的 `mcp.url`，或 stdio 的 `mcp.command/args`，二者选一。先通过 `zentao mcp-discover` 完成 initialize 和 tools/list，获得服务真实工具名、参数 schema 与只读声明；`zentao mcp-status` 也先发现工具，只有显式登记的只读 status 工具才会被调用。

```sh
node bin/pwf.mjs zentao mcp-discover --project /absolute/project/project.config.yaml
node bin/pwf.mjs zentao mcp-status --project /absolute/project/project.config.yaml
```

没有 MCP 端点或 stdio 命令时，状态保持待配置，不会尝试连接网站页面。工具发现无需产品/项目/执行或写映射；发现成功只代表 MCP 协议连接成功，正式交接仍需要目标 ID、接收人、批准基线和逐项写映射。

本机设置放在 `.local/`。HTTP 鉴权可以使用 `mcp.headersEnv: {Token: ZENTAO_MCP_TOKEN}`，值为环境变量名；如使用 `Authorization`，对应环境变量提供完整头值。stdio 使用 `mcp.env: {SERVER_TOKEN: ZENTAO_MCP_TOKEN}` 把指定环境变量映射给子进程，不继承无关凭据。凭据不放入参数、共享配置、需求 JSON 或静态评审包。

支持 `mcp.credentialsFile` 读取本地终端鉴权流程保存的 `{token,site,createdAt}`：仅当 `site` 严格匹配项目 `zentao.baseUrl` 时添加 HTTP `Token` 头。账号密码由本机 TTY 输入并换取 token，文件权限为 0600；配置与输出不保存密码。不存在 token 文件时仍可尝试工具发现，但写操作保持阻止。工具发现、状态结果和错误会对已知 token 脱敏。

本工作空间的终端鉴权入口如下，命令提示后再输入账号密码：

```sh
node workflow-kit/scripts/zentao-auth.mjs --site https://your-zentao.example --profile .local/zentao-mcp
```

分别输入账号和单行密码；密码中的空格、特殊符号及 Unicode 会原样提交，含换行的粘贴会在请求发送前被拒绝。登录只请求一次指定的 API2 JSON 端点，不自动重复尝试密码。取消或输入异常会恢复终端状态。

诊断代码区分认证拒绝与令牌响应问题：`ZENTAO_LOGIN_REJECTED` 表示服务端明确拒绝，`ZENTAO_RESPONSE_FORMAT/STATUS` 表示响应格式或状态不符合约定，`ZENTAO_TOKEN_MISSING/INVALID` 表示服务端声明成功但令牌缺失或无效。只有 `status: success` 与有效令牌同时存在才保存。已核对的通用失败/锁定文案可安全重建显示，其他服务端原因原文不输出，避免插件响应泄露凭据；需要结合禅道服务端登录日志诊断。通用的“检查用户名或密码”提示本身不能证明密码输入有误。

随后在业务项目本机配置中把 `zentao.mcp.credentialsFile` 指向该 profile 的 `credentials.json`，并单独登记已启动的 MCP 服务地址。该网站地址用于认证，不代表 MCP 端点。

### 显式工具映射

工具名和参数来自 tools/list，不凭命名猜测。`mcp.tools` 按对象类型登记 `create/update/read/findByExternalKey`；缺映射或工具名未在当前发现结果中出现时，拒绝写入。例如以下名称只是占位符，必须替换成实际发现结果：

```yaml
zentao:
  provider: mcp
  mcp:
    url: null # 用户指定的真实 MCP 端点，或登记 command/args
    tools:
      status:
        name: DISCOVERED_READ_ONLY_STATUS_TOOL
        readOnly: true
        arguments: {}
      story:
        create:
          name: DISCOVERED_CREATE_TOOL
          arguments:
            title: '${item.fields.title}'
            spec: '${item.fields.description}'
            verify: '${item.fields.acceptanceCriteria}'
            externalKey: '${item.externalKey}'
            product: '${item.target.productId}'
            reviewUrl: '${item.fields.reviewUrl}'
          result: {path: data, id: id}
        read:
          name: DISCOVERED_READ_TOOL
          readOnly: true
          arguments: {id: '${remoteId}'}
          result:
            path: data
            id: id
            externalKey: externalKey
            fields: {title: title, description: spec, acceptanceCriteria: verify, reviewUrl: reviewUrl}
```

还须登记实际 `update`；示例不预设任何实例的字段名称或返回封装。省略 `arguments` 时采用固定连接桥参数契约，省略 `result` 时要求工具直接返回标准化 `{id,externalKey?,fields}`。模板只读取明确的输入路径，不执行代码；整值占位符保留数组/对象类型。`result.path` 和字段值使用点路径；实例把验收条件序列化为 JSON 字符串时可显式配置 `result.parseJson: [acceptanceCriteria]`。

read、findByExternalKey、status 必须明确 `readOnly:true`；发现的工具若声明会修改数据，则拒绝把它用作只读工具。findByExternalKey 只有经实例确认完整精确查询、配置 `complete:true` 时才具有自动超时恢复能力；分页的一部分不能冒充“确认不存在”。产品写入拒绝负责人、排期、工时、状态等执行字段。

每次操作通过 SDK 建立连接、发现映射工具、调用并关闭连接，避免悬挂的 stdio 进程或 HTTP 会话。发现操作不调用 create/update。配置服务地址或 stdio 命令/参数发生变化时，目标指纹变化，旧映射不能直接复用；轮换 token 不改变目标身份。

### 显式备选连接

已有授权连接可以提供 `createBridgeAdapter(connection)`，模拟验证可以显式传入 `createMemoryAdapter()`。需要 REST 时必须明确配置 `provider: rest`，不会由 MCP 失败自动降级。

内置 REST 入口使用 `Token` 头及 `tokenEnv`，支持已登记的 story 路径：`POST /products/:productId/stories`、`PUT/GET /stories/:id`。`apiPrefix` 默认 `/api.php/v1`，实例采用其他版本时必须显式登记，例如 `/api.php/v2`。这只是实例适配入口，不代表所有禅道版本已经兼容；接通前需要确认版本、鉴权、权限、对象字段和返回结构。

已连接的官方 MCP/Skill 若具备所需能力，可提供 `createBridgeAdapter(connection)`；本工具不会自行安装插件或假定官方连接已存在。连接契约为：

```text
capabilities: { readBack: true, stableKeyLookup: boolean, itemTypes: ['story', ...] }
create(item)                         -> { id }
update(item, remoteId)               -> { id }
read(itemType, remoteId)             -> { id, externalKey?, fields }
findByExternalKey(itemType, key)     -> 完整匹配数组（仅在能力已确认时提供）
```

`fields` 统一为 `title/description/acceptanceCriteria/reviewUrl`。REST 写入只发送 `title/spec/verify`，描述内附稳定机器标记及固定评审地址；回读必须能恢复并核对相同产品字段。实例若过滤标记或改写正文，验证会失败，应调整实例适配，不能跳过校验。task 等其他对象先通过连接桥登记对象和字段能力，内置 REST 不猜测其必填字段。

默认 REST 未声称具有可靠的外部键检索能力。实例可通过经过检查的 `lookup` 回调提供完整精确查询；不能以某一页搜索结果冒充“确认不存在”。不支持可靠查询时，超时结果保持待核对，阻止盲目重建。通用 JSON 是标准交接包；只有获得目标实例导入模板后才派生表格，不宣称任意 CSV 可直接导入。

## 稳定身份与恢复

业务键为 `projectId/changeId/reqId/itemType/itemKey`，标题和 reviewId 不参与去重。同一 change 修改名称后仍复用对象；不同 change 的后续开发不会误更新旧任务。

每条写入之前持久化 intent，回读产品字段一致后立即提交该条映射，不等待整个批次完成。创建超时后先查询稳定标记；唯一匹配且内容一致则补全映射；多个匹配或结果不明则停止该条。批次中的其他成功映射保留。项目同步锁防止本地并发建单，进程已退出的本机锁可以恢复；状态不明的锁应人工核对。

目录包括 `plans/`、`mapping.json`、`attempts/` 与 `results/`；模拟数据在隔离的 `simulation/` 下。映射记录远端 ID、需求、change、基线、内容 hash、目标指纹与验证时间。目标实例或产品/执行发生变化时不能沿用旧映射，需明确迁移处置。

## 变更与状态

交接后的规则变化先通过 `createChangeImpact(ctx,{reviewId,document?})` 比较旧基线和新草稿；只列出变动项与 `dependsOn` 明确依赖项。删除仅生成取消/替代建议，保留页面、故事、任务和验收条件的历史，不自动删除远端对象。

存在移除项时，结果保留 `pendingDispositions`，不得把整批范围标为同步完成。项目经理在禅道人工处置后保留证据；本期没有自动取消或删除入口。

`confirmChangeImpact` 分别保存产品范围决策和项目经理执行影响确认，两者都需要实际提供的 actor、decision 和 evidence；不推测他人同意。批准新基线后，同步传入匹配的 `impactId`。没有规则变化的 B 不因为 A 发布了新评审地址就被改写。

产品同步仅控制产品字段。负责人、排期、工时、状态和技术任务细节归禅道与研发维护。真实同步、实际指派、项目经理接收分别记录；`recordAssignment` 与 `recordReceipt` 要求已有真实同步且提供明确证据。只有接收记录完成才推进到 HANDED_OFF。

`recordCollaboration` 保存 clarification/progress/known-issue，不因任务关闭推定实现或验收。`recordImplementation(ctx,{reviewId,version,evidence,actor?})` 只登记明确实现证据：当前批准基线匹配时写入 `state.changes[changeId].implementation={reviewId,version,evidence,recordedAt,actor?}` 并进入待验收；历史证据保存在 `implementations[reviewId]`。产品验收始终是独立结论，当前阶段保持预留。

## 本地验证

```sh
node --test tests/zentao.test.mjs tests/zentao-mcp.test.mjs tests/collaboration.test.mjs
```

覆盖冻结 JSON、未批准草案、缺配置、同 change 重复/跨 change 隔离、部分批次超时恢复、无可靠查询与多匹配冲突、产品字段白名单、A/B 影响隔离、移除与明确依赖、独立实现证据和产品验收状态。测试中的 REST 响应全部模拟，不写真实禅道。

MCP 测试使用官方 SDK 与临时本机 HTTP/stdio 服务，覆盖发现不写入、显式映射、只读声明冲突、缺 token、site 绑定、输出脱敏、目标隔离及幂等交接；不连接真实禅道或读取浏览器会话。
