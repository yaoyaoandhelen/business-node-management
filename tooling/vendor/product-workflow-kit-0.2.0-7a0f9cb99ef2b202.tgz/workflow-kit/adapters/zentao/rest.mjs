import {marker,parseMarker,productFields} from './shared.mjs';

/** ZenTao REST v1 story entry point. Instance compatibility must be checked first. */
export function createRestAdapter(ctx,{fetchImpl=globalThis.fetch,token=process.env[ctx.config.zentao?.tokenEnv||'ZENTAO_TOKEN'],lookup}={}){
  const c=ctx.config.zentao||{},prefix=c.apiPrefix||'/api.php/v1';
  if(prefix.includes('://')||!prefix.startsWith('/')||prefix.includes('..'))throw Error('zentao.apiPrefix 必须是实例内绝对路径');
  function url(path){if(!c.baseUrl)throw Error('缺少 zentao.baseUrl');const base=new URL(c.baseUrl);if(!['http:','https:'].includes(base.protocol)||base.username||base.password||base.search||base.hash)throw Error('禅道实例 URL 无效');return new URL(base.pathname.replace(/\/$/,'')+prefix+path,base.origin).href}
  async function request(method,path,body){
    if(!token)throw Error(`缺少鉴权环境变量 ${c.tokenEnv||'ZENTAO_TOKEN'}`);
    const response=await fetchImpl(url(path),{method,headers:{Token:token,Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(c.timeoutMs||15000)});
    if(!response.ok){const e=Error(`禅道 REST ${method} 返回 HTTP ${response.status}`);e.definitive=response.status>=400&&response.status<500&&response.status!==408&&response.status!==429;throw e}
    if(response.status===204)return {};
    const value=await response.json();if(value?.error||value?.status==='fail'){const e=Error('禅道 REST 拒绝请求，请核对实例字段和权限');e.definitive=true;throw e}return value;
  }
  function asStory(value){
    const v=value.story||value.data||value;if(v.id===undefined)throw Error('实例返回缺少远端 ID');
    const key=v.externalKey||parseMarker(v.spec||''),suffix=key?`\n\n${marker(key)}\n\n评审：`:null,index=suffix?(v.spec||'').lastIndexOf(suffix):-1;
    let acceptance=v.verify;try{acceptance=JSON.parse(v.verify)}catch{}
    return {id:String(v.id),itemType:'story',externalKey:key,fields:{title:v.title,description:index<0?v.spec:v.spec.slice(0,index),acceptanceCriteria:acceptance,reviewUrl:index<0?v.reviewUrl:v.spec.slice(index+suffix.length)}};
  }
  function payload(item){if(item.itemType!=='story')throw Error('内置 REST 入口仅登记 story；task 请先通过实例桥登记字段能力');const f=productFields(item.fields);return {title:f.title,spec:`${f.description||''}\n\n${marker(item.externalKey)}\n\n评审：${f.reviewUrl||''}`,verify:JSON.stringify(f.acceptanceCriteria||[])}}
  return {
    kind:'rest',isSimulation:false,authConfigured:Boolean(token),
    capabilities:{readBack:true,stableKeyLookup:typeof lookup==='function',itemTypes:['story']},
    async create(item){const result=await request('POST',`/products/${encodeURIComponent(item.target.productId)}/stories`,payload(item));const v=result.story||result.data||result;if(v.id===undefined)throw Error('创建响应缺少 ID，结果需核对');return {id:String(v.id)}},
    async update(item,id){const result=await request('PUT',`/stories/${encodeURIComponent(id)}`,payload(item));return {id:String((result.story||result.data||result).id||id)}},
    async read(type,id){if(type!=='story')throw Error('未登记此远端对象类型');return asStory(await request('GET',`/stories/${encodeURIComponent(id)}`))},
    async findByExternalKey(type,key){if(!lookup)throw Error('该实例尚未登记可靠外部键查询能力');const values=await lookup({itemType:type,externalKey:key,request});if(!Array.isArray(values))throw Error('外部键查询必须返回完整匹配数组');return values.map(v=>{const value=asStory(v);if(value.externalKey!==key)throw Error('外部键查询返回不匹配对象');return value})}
  };
}
