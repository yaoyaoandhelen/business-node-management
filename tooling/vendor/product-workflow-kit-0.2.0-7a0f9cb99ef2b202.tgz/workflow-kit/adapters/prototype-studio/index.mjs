import {readFile,writeFile,mkdir,rm,cp,rename,symlink,lstat,stat,realpath} from 'node:fs/promises';
import {join,dirname,relative,extname,resolve,sep} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {randomUUID} from 'node:crypto';
import {kitRoot,readJson,writeJson,hash,confined,filesUnder,assertPortsAvailable} from '../../lib/core.mjs';

const exec=promisify(execFile),adapterRoot=dirname(fileURLToPath(import.meta.url));
const manifestFile=join(kitRoot,'vendor/prototype-studio-source.json');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
const json=async(file)=>JSON.parse(await readFile(file,'utf8'));
async function verifyInputs(){
 const source=await json(manifestFile),archive=join(kitRoot,'vendor',source.archive);
 if(hash(await readFile(archive))!==source.sha256)throw Error('Studio 固定源码归档校验失败；请恢复锁定工具版本');
 const adaptation=await json(join(adapterRoot,'adaptation.lock.json'));
 for(const [file,digest]of Object.entries(adaptation.files))if(hash(await readFile(resolve(kitRoot,file)))!==digest)throw Error(`Studio 适配校验失败: ${file}`);
 return {source,archive,adaptation};
}
/** Returns a project-local, verified source runtime directory. */
export async function materializeStudio(ctx){
 const {source,archive,adaptation}=await verifyInputs();
 const key=hash({source:source.sha256,adaptation,projectId:ctx.projectId,root:ctx.root,ports:ctx.ports,origins:ctx.origins});
 const cache=join(ctx.paths.local,'studio-runtime'),runtime=join(cache,key.slice(0,24));
 await mkdir(cache,{recursive:true});
 try{const marker=await json(join(runtime,'.materialized.json'));for(const [file,digest]of Object.entries(marker.files))if(hash(await readFile(join(runtime,file)))!==digest)throw Error(`Studio 运行缓存校验失败: ${file}；清理该项目 .local/studio-runtime 后重试`);return runtime}catch(e){if(e.code!=='ENOENT')throw e}
 const staging=runtime+'.'+randomUUID()+'.tmp';await mkdir(staging,{recursive:true});
 try{
  const listing=await exec('tar',['-tzf',archive]);for(const entry of listing.stdout.split('\n').filter(Boolean))if(entry.startsWith('/')||entry.split('/').includes('..'))throw Error('Studio 归档路径不合法');
  await exec('tar',['-xzf',archive,'-C',staging]);
  for(const [file,digest]of Object.entries(source.files)){const item=join(staging,file);if((await lstat(item)).isSymbolicLink()||hash(await readFile(item))!==digest)throw Error(`Studio 归档源码校验失败: ${file}`)}
  await cp(join(adapterRoot,'overlay'),staging,{recursive:true});
  await mkdir(join(staging,'lib'),{recursive:true});await cp(join(kitRoot,'lib/requirements.mjs'),join(staging,'lib/requirements.mjs'));
  await writeJson(join(staging,'.runtime.json'),ctx);
  const inventory={};for(const file of await filesUnder(staging))inventory[relative(staging,file)]=hash(await readFile(file));
  await writeJson(join(staging,'.materialized.json'),{schemaVersion:1,sourceHash:source.sha256,adapterVersion:adaptation.version,files:inventory});
  await symlink(join(kitRoot,'node_modules'),join(staging,'node_modules'),'dir');
  await rename(staging,runtime);return runtime;
 }catch(e){await rm(staging,{recursive:true,force:true});throw e}
}
async function viteFor(root){
 const require=createRequire(join(root,'package.json'));let packageFile;
 try{packageFile=require.resolve('vite/package.json')}catch{throw Error(`业务项目缺少自己的 Vite 依赖；请在 ${root} 安装其锁定依赖`)}
 return import(pathToFileURL(join(dirname(packageFile),'dist/node/index.js')).href);
}
async function attachInspector(ctx,runtime){
 const directory=ctx.config.build.adapter==='static'?ctx.paths.prototype:join(ctx.paths.prototype,'public');
 const path=await confined(ctx.root,relative(ctx.root,join(directory,'inspector.js')));
 const source=await readFile(join(runtime,'packages/inspector/inspector.js'));
 try{if(hash(await readFile(path))!==hash(source))throw Error('业务原型 Inspector 与锁定工具版本不一致，请显式更新后重试')}catch(e){if(e.code!=='ENOENT')throw e;await mkdir(dirname(path),{recursive:true});await writeFile(path,source)}
 return path;
}
/** Prepare source assets before committing/freezing. Builds themselves never mutate source. */
export async function preparePrototype(ctx){const runtime=await materializeStudio(ctx);return {runtime,inspectorFile:await attachInspector(ctx,runtime)}}
/** Uses the registered business root, config and its own Vite installation. Returns output directory. */
export async function buildPrototype(ctx){
 const runtime=await materializeStudio(ctx);
 const root=await confined(ctx.root,ctx.config.build.root,{mustExist:true});
 const output=await confined(ctx.root,ctx.config.build.output);
 try{if((await lstat(resolve(ctx.root,ctx.config.build.output))).isSymbolicLink())throw Error('原型产物目录不允许符号链接')}catch(e){if(e.code!=='ENOENT')throw e}
 const inspector=ctx.config.build.adapter==='static'?join(root,'inspector.js'):join(root,'public/inspector.js');
 try{const file=await confined(ctx.root,relative(ctx.root,inspector),{mustExist:true});if(hash(await readFile(file))!==hash(await readFile(join(runtime,'packages/inspector/inspector.js'))))throw Error('业务原型 Inspector 与锁定工具版本不一致，请显式更新后重试')}catch(e){if(e.code==='ENOENT'||/路径不存在/.test(e.message))throw Error('业务原型尚未准备 Inspector；请先执行项目初始化或 preparePrototype(ctx)，再提交源码和冻结');throw e}
 if(ctx.config.build.adapter==='vite'){
  const config=await confined(ctx.root,ctx.config.build.config,{mustExist:true});
  const require=createRequire(join(root,'package.json'));let vitePackage;
  try{vitePackage=require.resolve('vite/package.json')}catch{throw Error(`业务项目缺少自己的 Vite 依赖；请在 ${root} 安装其锁定依赖`)}
  await exec(process.execPath,[join(dirname(vitePackage),'bin/vite.js'),'build','--config',config,'--base','./','--outDir',output,'--emptyOutDir'],{cwd:root,timeout:120000,maxBuffer:8*1024*1024});
 }else if(ctx.config.build.adapter!=='static')throw Error('未登记的业务构建适配器');
 const actual=await confined(ctx.root,relative(ctx.root,output),{mustExist:true});
 if(!(await stat(actual)).isDirectory())throw Error('原型产物必须是目录');await filesUnder(actual);return actual;
}
/** Builds the fixed Studio UI. Returns the static output directory. */
export async function buildStudio(ctx){
 const runtime=await materializeStudio(ctx),vite=await viteFor(kitRoot);
 await vite.build({configFile:join(runtime,'apps/studio/vite.config.js'),logLevel:'error'});return join(runtime,'apps/studio/dist');
}
function send(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(value))}
async function body(req){if(!req.headers['content-type']?.startsWith('application/json'))throw Object.assign(Error('需要 JSON 请求体'),{status:415});let size=0,parts=[];for await(const chunk of req){size+=chunk.length;if(size>1024*1024)throw Object.assign(Error('请求体超过 1 MB'),{status:413});parts.push(chunk)}try{return JSON.parse(Buffer.concat(parts).toString())}catch{throw Object.assign(Error('JSON 格式错误'),{status:400})}}
function keys(value,allowed){if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!allowed.includes(k)))throw Object.assign(Error('请求包含未允许的参数'),{status:400})}
async function staticFile(res,root,pathname,method='GET'){
 if(!['GET','HEAD'].includes(method))throw Object.assign(Error('评审快照只读'),{status:405});
 let file=await confined(root,'.'+decodeURIComponent(pathname),{mustExist:true});if((await stat(file)).isDirectory())file=await confined(root,relative(root,join(file,'index.html')),{mustExist:true});
 const content=await readFile(file);res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Content-Security-Policy':"frame-src 'self'; object-src 'none'"});res.end(method==='HEAD'?undefined:content);
}
async function createApi(ctx,runtime){
 const {Storage}=await import(pathToFileURL(join(runtime,'server/storage.mjs')).href),storage=new Storage(ctx);
 const hosts=new Set([ctx.origins.api,ctx.origins.studio].map(o=>new URL(o).host)),origins=new Set(Object.values(ctx.origins));
 const server=createServer(async(req,res)=>{try{
  if(!hosts.has(req.headers.host))throw Object.assign(Error('Host 不可信'),{status:403});if(req.headers.origin&&!origins.has(req.headers.origin))throw Object.assign(Error('请求来源不可信'),{status:403});
  const path=new URL(req.url,ctx.origins.api).pathname;
  if(path==='/api/health'&&req.method==='GET')return send(res,200,{ok:true,projectId:ctx.projectId});
  if(path==='/inspector.js'&&req.method==='GET'){res.writeHead(200,{'Content-Type':mime['.js']});return res.end(await readFile(join(runtime,'packages/inspector/inspector.js')))}
  if(path==='/api/projects'&&req.method==='GET')return send(res,200,await storage.projects());
  if(path==='/api/projects'&&req.method==='PUT')throw Object.assign(Error('项目配置由 project.config.yaml 统一管理'),{status:405});
  const match=path.match(/^\/api\/projects\/([\w.:-]+)\/(requirements|modules|reviews)(?:\/([\w.:-]+))?$/);
  if(match){const [,id,kind,reqId]=match;await storage.project(id);
   if(kind==='requirements'&&req.method==='GET'&&!reqId)return send(res,200,await storage.read(id));
   if(kind==='requirements'&&req.method==='PUT'&&reqId){const input=await body(req);keys(input,['revision','requirement']);return send(res,200,await storage.save(id,reqId,input))}
   if(kind==='modules'&&req.method==='PUT'&&!reqId){const input=await body(req);keys(input,['revision','modules']);return send(res,200,await storage.saveModules(id,input))}
   if(kind==='reviews'&&req.method==='POST'&&!reqId){const input=await body(req);keys(input,['revision']);const current=await storage.read(id);if(input.revision!==current.revision)throw Object.assign(Error('需求已更新，请重新加载'),{status:409});const {previewReview}=await import('../../lib/reviews.mjs');return send(res,201,await previewReview(ctx,{revision:current.revision}))}
  }
  if(path.startsWith('/review/')||path.startsWith('/preview/'))return await staticFile(res,join(ctx.paths.local,'site'),path,req.method);
  throw Object.assign(Error('接口不存在'),{status:404});
 }catch(e){if(!res.headersSent)send(res,e.status||(e.code==='ENOENT'?404:400),{error:e.message,errors:e.errors});else res.end()}});
 await new Promise((yes,no)=>{server.once('error',no);server.listen(ctx.ports.api,'127.0.0.1',yes)});return {server,storage};
}
/** Starts only the selected project. close() releases every listener. */
export async function startStudio(ctx){
 await assertPortsAvailable(ctx.ports);const runtime=await materializeStudio(ctx);await attachInspector(ctx,runtime);
 const closers=[],servers={};let closed=false;
 const close=async()=>{if(closed)return;closed=true;await Promise.allSettled(closers.reverse().map(fn=>fn()))};
 try{
  const api=await createApi(ctx,runtime);servers.api=api.server;closers.push(()=>new Promise(r=>api.server.close(r)));
  if(ctx.config.build.adapter==='vite'){
   const root=await confined(ctx.root,ctx.config.build.root,{mustExist:true}),config=await confined(ctx.root,ctx.config.build.config,{mustExist:true}),vite=await viteFor(root);
   const prototype=await vite.createServer({root,configFile:config,server:{host:'127.0.0.1',port:ctx.ports.prototype,strictPort:true},plugins:[{name:'registered-inspector-setup',configureServer(server){server.middlewares.use((req,res,next)=>{const path=req.url?.split('?')[0];if(path==='/inspector-config.js'){res.writeHead(200,{'Content-Type':mime['.js'],'Cache-Control':'no-store'});return res.end(`window.AIPrototypeInspectorConfig={allowedParentOrigins:${JSON.stringify([ctx.origins.studio,ctx.origins.prototype])}};`)}if(path==='/inspector.js'){readFile(join(runtime,'packages/inspector/inspector.js')).then(bytes=>{res.writeHead(200,{'Content-Type':mime['.js']});res.end(bytes)}).catch(next);return}next()})}}]});
   await prototype.listen();servers.prototype=prototype;closers.push(()=>prototype.close());
  }else{
   const prototype=createServer((req,res)=>{if(new URL(req.url,ctx.origins.prototype).pathname==='/inspector-config.js'){res.writeHead(200,{'Content-Type':mime['.js']});return res.end(`window.AIPrototypeInspectorConfig={allowedParentOrigins:${JSON.stringify([ctx.origins.studio,ctx.origins.prototype])}};`)}staticFile(res,ctx.paths.prototype,new URL(req.url,ctx.origins.prototype).pathname,req.method).catch(e=>send(res,404,{error:e.message}))});await new Promise((yes,no)=>{prototype.once('error',no);prototype.listen(ctx.ports.prototype,'127.0.0.1',yes)});servers.prototype=prototype;closers.push(()=>new Promise(r=>prototype.close(r)));
  }
  const vite=await viteFor(kitRoot),studio=await vite.createServer({configFile:join(runtime,'apps/studio/vite.config.js')});await studio.listen();servers.studio=studio;closers.push(()=>studio.close());
  return {url:ctx.origins.studio+'/',prototypeUrl:ctx.origins.prototype+'/',apiUrl:ctx.origins.api,runtime,servers,storage:api.storage,close};
 }catch(e){await close();throw e}
}
