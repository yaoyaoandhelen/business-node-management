---
name: product-workflow
description: 在已配置业务项目中推进需求分析、HTML原型、在线评审、禅道交接和研发协同，或继续中断的产品设计工作。用于阶段衔接和产物检查，不用于需求池或直接开发生产业务系统。
---

读取当前业务项目的 `AGENTS.md` 和 `project.config.yaml`。项目不明确时先查当前目录；有多个候选项目再请用户选择，不默认使用示例。

在业务项目根运行：

```sh
node tooling/run.mjs workflow status --project project.config.yaml
node tooling/run.mjs project check --project project.config.yaml
```

根据真实状态选择当前工作，不因用户说“继续”而重新初始化：

- 规则不清楚：复用 `prd-writer` 分析目标、范围、角色、流程和验收条件，将详细规则落实到唯一需求 JSON。分析记录只引用功能规则，不另写重复 PRD。
- 需要原型或评审修改：使用 `html-product-design`。
- 需要快照、在线地址或发布：使用 `github-pages-review`。
- 需要交接、研发进度、澄清或范围变更：使用 `zentao-handoff`，按需使用 OpenSpec 变更能力。

确定性操作使用工具箱 CLI；业务取舍由责任人决定。检查每项动作的产物与证据，准确区分预览就绪、已部署、已批准、已交接、已实现和待验收。阶段7只保留接口，任务关闭不等于产品验收。

需求保存事件只通知草稿变化，不自动执行 Codex 或远端写入。GitHub 与禅道目标按业务项目配置；缺目标时完成独立本地工作并列出缺项。不要伪造其他评审人或项目经理的确认。

在请求涉及发布/交接时遵循已有用户授权，先形成可核对产物；操作失败或结果未知要报告真实状态，不能用本地成功替代远程成功。
