export type StudioMode='preview'|'edit';
export interface Scenario{name:string;given:string;when:string;then:string[]}
export interface FieldDefinition{name:string;type:string;defaultValue:unknown;required:boolean;validation:string;message:string}
export interface StatisticDefinition{name:string;formula:string;scope:string;refresh:string}
export interface ElementBinding{pageId:string;elementId:string}
export interface Requirement{reqId:string;featureName:string;kind:'function'|'field'|'statistic';scenarios:Scenario[];acceptanceCriteria:Scenario[];fields:FieldDefinition[];statistics:StatisticDefinition[];interactionSteps:string[];businessRules:string[];fieldValidations:{field:string;rule:string;message:string}[];permissions:string[];exceptionHandling:string[];bindings:ElementBinding[];[metadata:string]:unknown}
export interface RequirementModule{id:string;name:string;description?:string;pageIds?:string[];reqIds:string[];children:RequirementModule[]}
export interface RequirementDocument{schemaVersion:2;projectId:string;revision:number;requirements:Record<string,Requirement>;modules:RequirementModule[];[metadata:string]:unknown}
/** Successful draft save only. This event never executes code or remote mutations. */
export interface RequirementChange{type:'requirements.changed';projectId:string;reqId:string;revision:number;requirement:Requirement}
