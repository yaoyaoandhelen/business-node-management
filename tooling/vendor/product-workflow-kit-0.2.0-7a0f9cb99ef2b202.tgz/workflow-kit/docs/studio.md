# 独立原型与需求工作台

工作台、业务原型和 JSON API 独立运行，统一入口是工作台地址。项目由 `--project <业务目录或project.config.yaml>` 显式选择，不回退 customer-demo，也不启动上游示例。

```sh
node bin/pwf.mjs studio dev --project ../projects/workflow-demo/project.config.yaml
```

命令输出本机统一入口。端口由业务目录 `.local/project.local.yaml` 的 `ports.studio`、`ports.prototype`、`ports.api` 登记；冲突会失败，应修改登记后重启。地址使用精确的 `http://127.0.0.1:<port>`。API Host/origin、Vite CSP、proxy 和开发 Inspector 配置均由同一项目上下文生成。

业务 HTML 在业务脚本前加载 `inspector-config.js` 和 `inspector.js`。开发服务只在开发时返回已登记的 Studio 和原型 origin。生产 `inspector-config.js` 应使用当前站点的 `window.location.origin`，不使用 `*`，不把本机端口带入生产运行依赖。Inspector 来自固定归档，初始化或显式 preparePrototype(ctx) 会补齐缺少的文件，构建阶段只验证、不写入源码；发现不同版本时明确停止，不静默覆盖。

默认显示完整业务页面；通过“功能需求”切换模块化说明。切换使用同一 iframe，保留已打开弹窗、输入和查询状态。需求空间等待 Inspector 编辑模式回执后才允许选择，编辑时暂停业务激活；返回设计空间恢复预览交互。业务必须使用模拟数据，Inspector 不替代业务自身的初始化和定时任务控制。

## 数据与兼容性

唯一可编辑功能规则保存在业务目录 `data/requirements/<projectId>.json`，而非浏览器 localStorage。schema v1 读取时规范化到 v2；首次成功保存前保留 `<projectId>.json.v1.bak`。保存整个文档并增加 revision，保留未知扩展元数据、模块树、reqId 和 bindings；不支持的 schema 版本阻止读取/降级保存。

v2 新增结构：

- `kind`: `function`、`field`、`statistic`；旧 ID 中的 `.field.` 和 `.stats.` 只作为兼容推断。
- `scenarios`、`acceptanceCriteria`: `{name,given,when,then:string[]}`。
- `fields`: `{name,type,defaultValue,required,validation,message}`，无默认值使用 `null`；数值和布尔值保留原类型。
- `statistics`: `{name,formula,scope,refresh}`。

原有 `interactionSteps`、`businessRules`、`fieldValidations`、`permissions`、`exceptionHandling`、`bindings` 保留。模块树只组织目录，不为每个字段生成导航；字段显示在所属子模块的集中表中。

保存请求必须带读取时的 revision。冲突返回 409，界面保留待保存草稿，应重新加载并处理差异。成功保存仍派发 `requirements.changed`，该事件只说明草稿保存，不执行 Codex、不修改原型源码、不发送禅道条目。

## 模块导入

需求空间的“导入模块目录”接受 `{id,name,reqIds,children,pageIds?}` 组成的 JSON 数组。服务验证重复模块 ID、悬空需求引用、页面引用和 revision。重新分组只修改 modules 与 revision，不删除功能说明或绑定。

同等 API 为 `PUT /api/projects/<projectId>/modules`，请求体 `{revision,modules}`。单需求保存使用 `PUT /api/projects/<projectId>/requirements/<reqId>`，请求体 `{revision,requirement}`。项目配置在业务 YAML 中维护，工作台不另外保存一份 projects.json。

正式冻结调用 `validateDocument(document,ctx,{formal:true})`：检查模块归属、原型绑定、功能验收场景，以及字段/统计的结构定义；错误指出具体 reqId。它是交接完整性检查，不表示产品已验收。

## 固定依赖与受控构建

`vendor/prototype-studio-source.tar.gz` 是从指定上游筛选的固定源码，清单与 SHA-256 位于 `vendor/prototype-studio-source.json`。不含上游需求数据、历史归档、demo、node_modules、Git 元数据或机器配置。外部原 Studio 未被修改。

集中适配在 `adapters/prototype-studio/overlay/`；`adaptation.lock.json` 校验适配文件及需求模型。运行时在业务 `.local/studio-runtime/<digest>/` 材料化。源归档、适配或既有缓存校验不符会明确失败；删除该业务缓存后可从锁定归档重建。业务数据不写入工具运行时。

`buildPrototype(ctx)` 仅使用已登记的 `build.adapter/root/config/output`。Vite 在业务目录自身 cwd、自己的依赖环境中执行；仅支持固定适配器参数，不接受 HTTP 传入命令。产物目录和每个文件都检查项目边界和符号链接。`buildStudio(ctx)` 生成固定 UI；两者返回静态目录字符串，交由评审发布器组装。

静态包使用同域 iframe 和相对路径，识别 `/preview/` 及 `/review/<reviewId>/`，也支持其前面的 GitHub Pages 仓库子路径。包内自带对应 UI、原型和 snapshot.json，静态访问无需运行本机 API。历史归档由评审发布器保存。

## 已执行的局部验证

```sh
node --test tests/requirements.test.mjs tests/studio.test.mjs
```

测试使用临时产品目录，覆盖旧版迁移与未知版本、结构字段往返、模块导入、两个项目的非默认端口/保存隔离、真实 JSON 恢复、revision 冲突、未登记 origin、HTTP 任意命令参数拒绝、缓存篡改/清理重建、符号链接产物拒绝、独立业务 cwd 构建和真实 Studio 静态构建。浏览器中的元素选择、状态保留和事件拦截须以端到端验证记录为准；这些局部测试不声称完成真实 GitHub 或禅道接通。
