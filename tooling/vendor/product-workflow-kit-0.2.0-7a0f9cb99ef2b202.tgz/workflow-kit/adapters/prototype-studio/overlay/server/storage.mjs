import {readFile,writeFile,rename,mkdir,copyFile} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {randomUUID} from 'node:crypto';
import {validateDocument,normalizeDocument,validateRequirement,importModules} from '../lib/requirements.mjs';
export {validateRequirement};
export class HttpError extends Error{constructor(status,message){super(message);this.status=status}}
export class Storage{
 constructor(context){this.context=context;this.root=context.paths.data;this.queue=Promise.resolve()}
 async projects(){const c=this.context;return {schemaVersion:1,projects:[{id:c.projectId,name:c.config.name,description:'独立业务原型 · 本地需求编辑',baseUrl:c.origins.prototype+'/',allowedOrigins:[c.origins.prototype],pages:c.config.pages}]}}
 async project(id){if(id!==this.context.projectId)throw new HttpError(404,'项目未登记');return (await this.projects()).projects[0]}
 async read(id){await this.project(id);let doc;try{doc=JSON.parse(await readFile(this.context.paths.requirements,'utf8'))}catch(e){if(e.code==='ENOENT')return {schemaVersion:2,projectId:id,revision:0,requirements:{},modules:[]};throw e}return validateDocument(doc,this.context)}
 transaction(fn){const result=this.queue.then(fn);this.queue=result.catch(()=>{});return result}
 async atomic(file,value){await mkdir(dirname(file),{recursive:true});const temp=file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(value,null,2)+'\n');await rename(temp,file)}
 async backupV1(){try{const file=this.context.paths.requirements;const original=JSON.parse(await readFile(file,'utf8'));if(original.schemaVersion===1){try{await copyFile(file,file+'.v1.bak',1)}catch(e){if(e.code!=='EEXIST')throw e}}}catch(e){if(e.code!=='ENOENT')throw e}}
 save(id,reqId,body){return this.transaction(async()=>{await this.project(id);const doc=await this.read(id);if(body.revision!==doc.revision)throw new HttpError(409,'文件已更新，请重新加载后再保存');doc.requirements[reqId]=validateRequirement(body.requirement,reqId,this.context);doc.revision++;const result=validateDocument(doc,this.context);await this.backupV1();await this.atomic(this.context.paths.requirements,result);return result})}
 saveModules(id,body){return this.transaction(async()=>{await this.project(id);const doc=await this.read(id);if(body.revision!==doc.revision)throw new HttpError(409,'文件已更新，请重新加载后再导入');const result=importModules(doc,body.modules,this.context,{revision:body.revision});await this.backupV1();await this.atomic(this.context.paths.requirements,result);return result})}
 async saveProject(){throw new HttpError(405,'请在业务项目 project.config.yaml 中修改登记配置并重启；工作台不另建项目副本')}
}
