import {mkdir,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {hash,readJson,writeJson,readState,writeState} from '../../lib/core.mjs';
import {approvedReview,deliveryPaths,externalKey,loadMapping,matchesRemote,now,productFields,saveMapping,targetFingerprint,withDeliveryLock} from './shared.mjs';
import {createRestAdapter} from './rest.mjs';
import {createBridgeAdapter} from './bridge.mjs';
import {createMcpAdapter,missingMcpConfig} from './mcp.mjs';
import {createMemoryAdapter} from './mock.mjs';
export {createMemoryAdapter,createMockAdapter} from './mock.mjs';
export {createRestAdapter} from './rest.mjs';
export {createBridgeAdapter} from './bridge.mjs';
export {createMcpAdapter,discoverMcpTools,missingMcpConfig} from './mcp.mjs';
export {externalKey,PRODUCT_FIELDS} from './shared.mjs';

export function missingZentaoConfig(ctx,{adapter}={}){
  if(adapter?.isSimulation)return [];
  const c=ctx.config.zentao||{};
  if(adapter?.kind==='mcp'||(!adapter&&['mcp',undefined].includes(c.provider)))return [...['productId','projectId','executionId','receiver'].filter(k=>!c[k]).map(k=>`zentao.${k}`),...missingMcpConfig(ctx)];
  const missing=['baseUrl','productId','projectId','executionId','receiver'].filter(k=>!c[k]).map(k=>`zentao.${k}`);
  if(adapter?.kind!=='bridge'&&!adapter?.authConfigured&&!process.env[c.tokenEnv||'ZENTAO_TOKEN'])missing.push(`env.${c.tokenEnv||'ZENTAO_TOKEN'}`);
  return missing;
}
export function createAdapter(ctx,{bridge,...options}={}){
  if(bridge)return createBridgeAdapter(bridge);
  const provider=ctx.config.zentao?.provider||'mcp';
  if(provider==='mcp')return createMcpAdapter(ctx,options);
  if(provider==='rest')return createRestAdapter(ctx,options);
  if(provider==='mock')return createMemoryAdapter(options);
  throw Error(`未登记禅道 provider: ${provider}；不会回退 REST 或浏览器`);
}
function ruleHash(req){const {updatedAt,...business}=req;return hash(business)}
function reviewLink(ctx,id){const url=ctx.config.github?.url;if(!url)return `${ctx.config.github?.basePath||'/'}review/${id}/`;return new URL(`review/${id}/`,url.endsWith('/')?url:url+'/').href}
function fieldsFor(req,link){
  const sections=[['场景',req.scenarios],['交互',req.interactionSteps],['业务规则',req.businessRules],['字段',req.fields||req.fieldValidations],['统计口径',req.statistics],['权限',req.permissions],['异常处理',req.exceptionHandling]];
  return {title:req.featureName||req.reqId,description:sections.filter(([,v])=>v&&(!Array.isArray(v)||v.length)).map(([title,v])=>`${title}\n${JSON.stringify(v,null,2)}`).join('\n\n'),acceptanceCriteria:structuredClone(req.acceptanceCriteria||[]),reviewUrl:link};
}
function changeState(state,id){return state.changes[id]||(state.changes[id]={stage:'ANALYZING',acceptedReviewId:null,implementation:null,productAcceptance:{status:'reserved'}})}
function planHash(plan){const {planHash,file,...body}=plan;return hash(body)}
function checkPlan(ctx,plan){if(plan.projectId!==ctx.projectId||plan.schemaVersion!==1||plan.planHash!==planHash(plan))throw Error('交接计划项目、版本或内容校验不符');for(const item of plan.items){if(item.externalKey!==externalKey(item)||item.contentHash!==hash(productFields(item.fields)))throw Error('交接条目校验不符')}}

export async function createHandoffPlan(ctx,{reviewId,draft=false,document,changeId,items,review}={}){
  let frozen;
  if(reviewId)frozen=await approvedReview(ctx,reviewId,review,{draft});
  else{if(!draft)throw Error('正式交接必须指定已批准 reviewId');document=document||await readJson(ctx.paths.requirements);frozen={document,manifest:{projectId:ctx.projectId,changeId,requirementHash:hash(document),kind:'draft'},approved:false}}
  const m=frozen.manifest;document=frozen.document;changeId=changeId||m.changeId||ctx.config.activeChangeId;
  if(m.changeId&&m.changeId!==changeId)throw Error('changeId 与冻结基线不符');
  if(document.projectId!==ctx.projectId)throw Error('需求文档项目不符');
  const mapping=await loadMapping(ctx),link=reviewId?reviewLink(ctx,reviewId):null,c=ctx.config.zentao||{};
  const requested=items||Object.values(document.requirements).filter(r=>r.kind!=='field').map(r=>({reqId:r.reqId,itemType:'story',itemKey:'main'}));
  const keys=new Set();const entries=requested.map(input=>{
    const req=document.requirements[input.reqId];if(!req)throw Error(`冻结基线不存在需求 ${input.reqId}`);
    const entry={projectId:ctx.projectId,changeId,reqId:input.reqId,itemType:input.itemType||'story',itemKey:input.itemKey||'main',target:{productId:c.productId||null,projectId:c.projectId||null,executionId:c.executionId||null}};
    entry.externalKey=externalKey(entry);if(keys.has(entry.externalKey))throw Error('交接计划存在重复业务键');keys.add(entry.externalKey);
    // Rules always come from the frozen JSON, including when the caller suggests task splits.
    entry.fields=productFields(fieldsFor(req,link));entry.ruleHash=ruleHash(req);entry.contentHash=hash(entry.fields);
    const previous=mapping.entries[entry.externalKey];entry.operation=!previous?'create':previous.ruleHash===entry.ruleHash?'skip':'update';
    entry.suggestedTasks=[{itemKey:'business-flow',name:`实现 ${req.featureName||req.reqId} 的业务流程与验收场景`,estimate:null,technicalSplit:'由研发确认，产品计划不覆盖技术任务'}];return entry;
  });
  const currentReqIds=new Set(Object.keys(document.requirements));
  const cancellationSuggestions=Object.entries(mapping.entries).filter(([,v])=>v.changeId===changeId&&!currentReqIds.has(v.reqId)).map(([key,v])=>({externalKey:key,id:v.id,reqId:v.reqId,proposal:'cancel-or-replace',automaticDelete:false}));
  const body={schemaVersion:1,projectId:ctx.projectId,changeId,reviewId:reviewId||null,manifestHash:m.manifestHash||null,requirementHash:m.requirementHash,draft:!frozen.approved||draft,reviewUrl:link,linkStatus:link&&/^https?:\/\//.test(link)?'configured-url':'awaiting-publication',receiver:c.receiver||null,targetFingerprint:targetFingerprint(ctx),items:entries,cancellationSuggestions,missing:missingZentaoConfig(ctx),delivery:{prepared:true,synchronized:false,assigned:false,received:false}};
  const plan={...body,id:'handoff-'+hash(body).slice(0,24)};plan.planHash=planHash(plan);
  const {root}=await deliveryPaths(ctx);const file=join(root,'plans',plan.id+'.json');await writeJson(file,plan);await writeJson(join(root,'latest-plan.json'),{id:plan.id,file:`plans/${plan.id}.json`,draft:plan.draft});
  return {...plan,file};
}

async function pendingAttempts(base,key){
  let files=[];try{files=await readdir(join(base,'attempts'))}catch(e){if(e.code!=='ENOENT')throw e}
  const result=[];for(const file of files.filter(f=>f.endsWith('.json'))){const value=await readJson(join(base,'attempts',file));if(value.externalKey===key&&['intent','uncertain','conflict'].includes(value.status))result.push({...value,file:join(base,'attempts',file)})}return result.sort((a,b)=>a.createdAt.localeCompare(b.createdAt));
}
async function finishAttempt(file,attempt,patch){const {file:ignored,...body}=attempt;return writeJson(file,{...body,...patch,updatedAt:now()})}
function mappingEntry(plan,item,id,simulation){return {id:String(id),itemType:item.itemType,reqId:item.reqId,itemKey:item.itemKey,changeId:plan.changeId,reviewId:plan.reviewId,manifestHash:plan.manifestHash,contentHash:item.contentHash,ruleHash:item.ruleHash,targetFingerprint:plan.targetFingerprint,simulation,verifiedAt:now()}}
async function recover(ctx,plan,item,adapter,mapping,attempt){
  if(attempt.targetFingerprint&&attempt.targetFingerprint!==plan.targetFingerprint)return {externalKey:item.externalKey,status:'target-conflict'};
  let remote;
  try{
    if(attempt.remoteId){const found=await adapter.read(item.itemType,attempt.remoteId);remote=found?[found]:[]}
    else if(adapter.capabilities.stableKeyLookup&&adapter.findByExternalKey)remote=await adapter.findByExternalKey(item.itemType,item.externalKey,item);
    else{await finishAttempt(attempt.file,attempt,{status:'uncertain',reason:'连接不支持可靠外部键查询，请人工核对'});return {externalKey:item.externalKey,status:'needs-reconciliation'}}
    if(remote.length>1){await finishAttempt(attempt.file,attempt,{status:'conflict',reason:'远端存在多个匹配业务键'});return {externalKey:item.externalKey,status:'conflict'}}
    if(!remote.length){await finishAttempt(attempt.file,attempt,{status:'not-found',reason:'可靠查询确认当前不存在对象'});return {externalKey:item.externalKey,status:'not-found'}}
    if(!matchesRemote(remote[0],attempt.item||item)){await finishAttempt(attempt.file,attempt,{status:'uncertain',remoteId:String(remote[0].id),reason:'已定位远端对象，但产品字段与请求内容不一致，需人工核对'});return {externalKey:item.externalKey,status:'needs-reconciliation'}}
    const verifiedItem=attempt.item||item;const verifiedPlan={...plan,reviewId:attempt.reviewId,manifestHash:attempt.manifestHash};mapping.entries[item.externalKey]=mappingEntry(verifiedPlan,verifiedItem,remote[0].id,adapter.isSimulation===true);await saveMapping(ctx,mapping);await finishAttempt(attempt.file,attempt,{status:'verified',remoteId:String(remote[0].id),reconciledAt:now()});return {externalKey:item.externalKey,status:'reconciled',id:String(remote[0].id)};
  }catch{await finishAttempt(attempt.file,attempt,{status:'uncertain',reason:'核对请求未能确认结果，请再次核对'});return {externalKey:item.externalKey,status:'needs-reconciliation'}}
}
async function requireImpact(ctx,plan,mapping,impactId){
  const previous=Object.values(mapping.entries).filter(v=>v.changeId===plan.changeId&&v.reviewId!==plan.reviewId);
  if(!previous.length)return;
  const changed=plan.items.some(item=>{const old=mapping.entries[item.externalKey];return !old||old.ruleHash!==item.ruleHash});
  if(!changed&&!plan.cancellationSuggestions.length)return;
  if(!impactId)throw Error('已交接范围变化需要影响清单及产品/项目经理确认');
  if(!/^[a-z0-9-]+$/.test(impactId))throw Error('影响清单 ID 无效');
  const impact=await readJson(join(ctx.root,'collaboration/impacts',impactId+'.json'));
  if(impact.projectId!==ctx.projectId||impact.changeId!==plan.changeId||impact.targetRequirementHash!==plan.requirementHash||impact.productDecision?.decision!=='approved'||impact.projectManagerConfirmation?.decision!=='approved')throw Error('影响清单与交接目标不符或确认未完成');
  const baseIds=new Set(previous.map(v=>v.reviewId));if(!baseIds.has(impact.reviewId))throw Error('影响清单未引用本次变化的已交接基线');
}
async function validateSync(ctx,plan,{adapter,review}){
  checkPlan(ctx,plan);if(plan.draft)throw Error('草案交接包不能执行同步');
  const frozen=await approvedReview(ctx,plan.reviewId,review);
  if(frozen.manifest.manifestHash!==plan.manifestHash||frozen.manifest.requirementHash!==plan.requirementHash)throw Error('交接计划与批准基线校验不符');
  if(plan.reviewUrl!==reviewLink(ctx,plan.reviewId))throw Error('交接地址与项目固定评审地址不符，请重新核对计划');
  for(const item of plan.items){const req=frozen.document.requirements[item.reqId];if(!req||item.ruleHash!==ruleHash(req)||item.contentHash!==hash(fieldsFor(req,plan.reviewUrl)))throw Error('交接条目规则不属于批准需求基线')}
  if(plan.targetFingerprint!==targetFingerprint(ctx))throw Error('禅道目标已变化，请重新生成并核对计划');
  if(!adapter?.capabilities?.readBack)throw Error('连接不具备必需的远端回读能力');
  for(const item of plan.items)if(!adapter.capabilities.itemTypes?.includes(item.itemType))throw Error(`连接尚未登记 ${item.itemType} 对象能力`);
  return frozen;
}

export async function syncHandoff(ctx,plan,{adapter=createAdapter(ctx),allowWrite=false,impactId,review}={}){
  checkPlan(ctx,plan);const missing=missingZentaoConfig(ctx,{adapter});if(!allowWrite)return {status:'dry-run',simulation:adapter.isSimulation===true,missing,planId:plan.id,items:plan.items.map(i=>({externalKey:i.externalKey,operation:i.operation})),sent:false};
  const observedRevision=(await readState(ctx)).stateRevision;
  const frozen=await validateSync(ctx,plan,{adapter,review});
  if(!adapter.isSimulation&&plan.linkStatus!=='configured-url')missing.push('review.publicUrl');
  if(missing.length)return {status:'pending-configuration',missing,sent:false};
  return withDeliveryLock(ctx,async()=>{
    const {base}=await deliveryPaths(ctx,adapter.isSimulation);await mkdir(join(base,'attempts'),{recursive:true});const mapping=await loadMapping(ctx,adapter.isSimulation);
    const sourceIds=new Set(Object.keys(frozen.document.requirements));
    const pendingDispositions=Object.entries(mapping.entries).filter(([,v])=>v.changeId===plan.changeId&&!sourceIds.has(v.reqId)).map(([key,v])=>({externalKey:key,id:v.id,reqId:v.reqId,proposal:'cancel-or-replace',automaticDelete:false}));
    await requireImpact(ctx,{...plan,cancellationSuggestions:pendingDispositions},mapping,impactId);const results=[];
    for(const item of plan.items){
      let blocked=false;for(const attempt of await pendingAttempts(base,item.externalKey)){const result=await recover(ctx,plan,item,adapter,mapping,attempt);if(['conflict','needs-reconciliation','target-conflict'].includes(result.status)){results.push(result);blocked=true;break}}
      if(blocked)continue;
      const previous=mapping.entries[item.externalKey];if(previous?.targetFingerprint&&previous.targetFingerprint!==plan.targetFingerprint){results.push({externalKey:item.externalKey,status:'target-conflict'});continue}
      if(previous?.ruleHash===item.ruleHash){results.push({externalKey:item.externalKey,status:'skipped',id:previous.id});continue}
      const attempt={schemaVersion:1,id:randomUUID(),projectId:ctx.projectId,changeId:plan.changeId,reviewId:plan.reviewId,manifestHash:plan.manifestHash,targetFingerprint:plan.targetFingerprint,externalKey:item.externalKey,item:structuredClone(item),operation:previous?'update':'create',remoteId:previous?.id||null,status:'intent',createdAt:now()};const file=join(base,'attempts',attempt.id+'.json');await writeJson(file,attempt);
      try{
        const payload={...item,fields:productFields(item.fields)};const response=previous?await adapter.update(payload,previous.id):await adapter.create(payload);const id=String(response?.id||previous?.id||'');if(!id)throw Error('写入结果缺少可核对 ID');attempt.remoteId=id;await finishAttempt(file,attempt,{status:'intent',remoteId:id});
        const actual=await adapter.read(item.itemType,id);if(!matchesRemote(actual,item))throw Error('远端产品字段回读不一致');
        mapping.entries[item.externalKey]=mappingEntry(plan,item,id,adapter.isSimulation===true);await saveMapping(ctx,mapping);await finishAttempt(file,attempt,{status:'verified',remoteId:id});results.push({externalKey:item.externalKey,status:previous?'updated':'created',id});
      }catch(error){await finishAttempt(file,attempt,{status:error.definitive?'failed':'uncertain',reason:error.definitive?'远端明确拒绝请求；核对字段与权限后重试':'请求结果未知；必须核对后继续'});results.push({externalKey:item.externalKey,status:error.definitive?'failed':'needs-reconciliation'});}
    }
    const complete=results.every(x=>['created','updated','skipped'].includes(x.status))&&!pendingDispositions.length;const result={schemaVersion:1,planId:plan.id,reviewId:plan.reviewId,simulation:adapter.isSimulation===true,status:complete?(adapter.isSimulation?'simulated':'synchronized'):'partial',items:results,pendingDispositions,sent:complete&&!adapter.isSimulation,assigned:false,received:false,recordedAt:now()};await writeJson(join(base,'results',plan.id+'.json'),result);
    const state=await readState(ctx),change=changeState(state,plan.changeId);change.zentao=change.zentao||{};
    if(adapter.isSimulation)change.zentao.simulation={reviewId:plan.reviewId,status:result.status,planId:plan.id,recordedAt:result.recordedAt};
    else if(complete)change.zentao={...change.zentao,synchronizedReviewId:plan.reviewId,planId:plan.id,synchronizedAt:result.recordedAt,assignment:{status:'unconfirmed'},receipt:{status:'awaiting'}};
    await writeState(ctx,state,{expectedRevision:observedRevision});return result;
  });
}

export async function reconcileHandoff(ctx,plan,{adapter=createAdapter(ctx),review}={}){
  await validateSync(ctx,plan,{adapter,review});const missing=missingZentaoConfig(ctx,{adapter});if(missing.length)return {status:'pending-configuration',missing,sent:false};
  return withDeliveryLock(ctx,async()=>{const {base}=await deliveryPaths(ctx,adapter.isSimulation),mapping=await loadMapping(ctx,adapter.isSimulation),results=[];for(const item of plan.items)for(const attempt of await pendingAttempts(base,item.externalKey))results.push(await recover(ctx,plan,item,adapter,mapping,attempt));return {status:results.some(x=>['needs-reconciliation','conflict','target-conflict'].includes(x.status))?'needs-reconciliation':'reconciled',simulation:adapter.isSimulation===true,items:results,sent:false}});
}
