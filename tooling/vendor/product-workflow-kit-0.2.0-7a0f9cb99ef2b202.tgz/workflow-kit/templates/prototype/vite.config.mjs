import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url));
export default {root,base:'./',build:{outDir:'dist',emptyOutDir:true,rollupOptions:{input:{index:resolve(root,'index.html'),archived:resolve(root,'archived.html')}}}};
