# 原型评审快照与 GitHub Pages

每个业务项目在自己的 `project.config.yaml` 中配置 GitHub 目标；工具箱没有全局发布仓库，也不会回退到 customer-demo。项目可以先完成本机预览与静态导出，再接通自己的仓库。

## 本机预览与正式冻结

```sh
node workflow-kit/bin/pwf.mjs review preview --project projects/workflow-demo/project.config.yaml
node workflow-kit/bin/pwf.mjs review freeze --project projects/workflow-demo/project.config.yaml
node workflow-kit/bin/pwf.mjs review export --project projects/workflow-demo/project.config.yaml --output _site
```

`preview` 可使用未提交草稿，来源明确标为 preview，存入业务项目 `.local/reviews/<reviewId>/`。`previewReview()` 也会将完整静态站点导出到 `.local/site/`；本地 Studio 的预览按钮调用该入口。

正式 `freeze` 要求业务项目是独立 Git 仓库，原型源文件、需求 JSON 及项目配置均已提交。只检查这些业务输入，不会把生成的日志或静态归档当作未提交源码。没有 Git 提交或存在未提交输入时会指出问题并停止，不能用 preview 作为正式交接基线。

冻结先记录源码/需求/工具摘要，再构建、复核输入，最后原子写入 `site-archive/review/<reviewId>/`。失败不会更新成功指针。manifest 包含源码提交、逐文件源码摘要、需求 revision/hash、工具/适配源码证据及静态文件 hash。需求 revision 相同而原型改变，也会得到不同基线。

同一 reviewId 只允许相同输入重试；已存在的快照会校验后复用，不重新随机生成。任何文件缺失、被修改或多出未知文件都会拒绝作为既有快照使用。

## 记录真实评审决定

批准必须显式提供记录该决定的人和 `approved` / `rejected`，工具不会代替业务评审参与者确认。

```sh
node workflow-kit/bin/pwf.mjs review approve --project projects/workflow-demo/project.config.yaml --review REVIEW_ID --actor REVIEWER --decision approved
```

决定保存在 `reviews/<reviewId>/approval.json` 和历史记录中，并引用不可变 manifest hash；静态包不会因为批准而改变。批准只建立已接受基线，不代表研发实现或产品验收。新基线不继承旧基线的实现/验收完成结论。

## 持久归档与干净环境导出

正式 `site-archive/`、`reviews/` 和项目状态应随业务仓库提交；`.local/` 不提交。新版本冻结后，一并提交新归档和相应元数据。首次正式冻结前，先提交原型与需求输入；生成的归档在冻结后另行提交即可。

`review export` 从全部持久归档重新组装站点，允许清理临时 `_site/`，不会清理 `site-archive/`。输出包含根入口、可用的本机 preview 和全部 `review/<reviewId>/`。干净 CI 没有本机 preview 时，根入口回退到正式评审版本，历史链接仍保持原字节和 hash。

只允许导出到项目 `.local/` 下或 `_site/`，防止误覆盖源码。回退使用已保留的正式版本或对应 Git 历史；不要修改旧评审目录，不要仅保留最新快照。资源应使用相对 URL，配置页面也必须使用相对路径；网站根路径及 `/repository-name/` 子路径使用同一静态包。

完整包包含 Studio UI、原型、需求 snapshot 和资源。停止本机工作台、业务、文件服务后，可用任意静态 HTTP 服务打开包。生产 Inspector 的父来源使用当前同域精确 origin；静态评审 UI 不提供需求保存操作。不要用 `file://` 或 localhost 声称已经向团队上线。

## 每个项目独立配置 Pages

```yaml
github:
  owner: YOUR_OWNER
  repository: THIS_PROJECT_REPOSITORY
  branch: YOUR_RELEASE_BRANCH
  basePath: /THIS_PROJECT_REPOSITORY/
```

独立用户站点或自定义域可配置 `basePath: /`。以上值必须由实际项目确定，不能用示例代替。

`installPagesTemplate()` 安装 `.github/workflows/pages.yml` 和 `tooling/restore.mjs`，已有文件不覆盖。未配置分支时模板使用不会意外部署的占位分支，接通前需重新生成或明确修改。仓库 Pages 来源需设为 GitHub Actions，并为项目运行账号提供所需权限。

工具箱分发使用项目内已提交的 `tooling/toolchain.json` 与 `tooling/vendor/*.tgz`：

```json
{"schemaVersion":1,"packageArchive":"tooling/vendor/workflow-kit-VERSION.tgz","sha256":"SHA256_OF_THE_ARCHIVE"}
```

归档必须只有一个顶层目录，包含源码、`package-lock.json` 和 `bin/pwf.mjs`，不包含 node_modules 或本机缓存。恢复脚本先核对 sha256、路径和文件类型，再原子恢复到 `.local/workflow-kit`；失败不会下载替代版本或使用机器绝对路径。Actions 执行 `npm ci`，从业务仓库全部正式归档组装站点后上传完整 Pages artifact。

## 发布、重试与远端验证

```sh
node workflow-kit/bin/pwf.mjs pages publish --project projects/workflow-demo/project.config.yaml --review REVIEW_ID
node workflow-kit/bin/pwf.mjs pages publish --project projects/workflow-demo/project.config.yaml --review REVIEW_ID --execute
node workflow-kit/bin/pwf.mjs pages verify --project projects/workflow-demo/project.config.yaml --review REVIEW_ID --url ACTUAL_DEPLOYMENT_URL
```

没有 `--execute` 时只准备本地产物。GitHub 目标缺失时返回具体配置项与本地导出位置，不发生远端调用。正式发送前需将工具依赖、目标快照和元数据提交/推送到该项目仓库；发布命令不会替用户猜测仓库、推送分支或新建业务仓库。

默认远端适配调用 `gh workflow run`，使用该项目 owner/repository/branch 和原 reviewId，记录唯一请求号与工作流地址。dispatch 只是 `deployment_pending`，不是已上线。重试仍使用原快照身份。Actions 部署返回的真实 `page_url` 会进入独立验证步骤，检查当前版本及至少一个历史版本。

验证不仅检查 HTTP 200，还读取 manifest 并核对 projectId、reviewId、自身 hash 和本地冻结 manifest hash，再核对 snapshot、入口页面及其脚本/CSS 等关键资源的字节 hash。返回旧版本、错误路径、HTTP 失败或资源 hash 不符都失败，不能覆盖此前已验证 URL。localhost 不登记为团队线上地址。

发布 intent、pending、部署证据、验证成功/失败分别保存在 `reviews/<reviewId>/publication.json`。默认适配器不会把没有实际部署 URL 的请求标记成功；可通过相同适配契约接入返回 deploymentId 与实际 URL 的部署工具。测试使用隔离 mock，不代表 GitHub 真实接通。
