# 产品设计工作流工具箱

本工具箱提供需求分析、HTML 原型、预览展示、评审优化、禅道交接与研发协同的共享实现。每个业务项目独立保存需求、原型、OpenSpec、评审及交接证据，并使用自己的工具锁和外部目标。完整产品验收目前只保留条件与证据入口。

从 [完整使用手册](docs/user-guide.md) 开始；阶段与门槛见 [工作流](docs/workflow.md)，无历史接手和并行工作见 [Agent 协议](docs/agent-protocol.md)。Agent 同时读取本目录 [AGENTS.md](AGENTS.md)。

## 安装与发现

Node.js 22.12+，在工具箱根执行：

```sh
npm ci
node bin/pwf.mjs help
```

0.2 的发现、上下文、交接、导入和兼容 bootstrap 已完成本地及隔离环境核验，实际范围和未测项见验证记录。

处于完整工作空间时，可从工具箱目录发现项目：

```sh
node bin/pwf.mjs project list --workspace .. --include-examples
```

用户明确的项目优先；不默认进入客户示例，不写所有会话共用的“当前项目”。独立业务项目可通过其配置直接定位，不需要搬回工作空间。

## 业务项目的入口

从业务项目根使用 `node tooling/run.mjs`。首次恢复或迁出后：

```sh
node tooling/restore.mjs
npm ci --prefix .local/workflow-kit --omit=dev
node tooling/run.mjs project check --project project.config.yaml
```

恢复会核对工具锁、归档、包身份和材料化内容。它不安装原型依赖、不恢复本机凭据，也不表示原开发服务已经运行。业务原型依赖按自己的 package-lock 安装。

0.2 项目读取上下文：

```sh
node tooling/run.mjs workflow context --project project.config.yaml --intent resume
node tooling/run.mjs workflow next --project project.config.yaml --intent resume
```

上下文区分登记阶段与证据可用性；默认只读，不启动、保存或查询远端。需求规则只编辑项目 JSON，OpenSpec 为受控投影。保存交接的修订和来源规则见 Agent 协议。

## 能力与详细接入

| 工作 | 普通文件入口 |
| --- | --- |
| 选择阶段、分析、继续 | [.agents/skills/product-workflow/SKILL.md](.agents/skills/product-workflow/SKILL.md) |
| 原型与需求编辑 | [.agents/skills/html-product-design/SKILL.md](.agents/skills/html-product-design/SKILL.md) |
| 冻结、评审包与 Pages | [.agents/skills/github-pages-review/SKILL.md](.agents/skills/github-pages-review/SKILL.md) |
| 禅道、范围变更与研发协同 | [.agents/skills/zentao-handoff/SKILL.md](.agents/skills/zentao-handoff/SKILL.md) |

无需原生 Skill 注册也可直接读取上述文件。具体接入见 [Studio](docs/studio.md)、[Pages](docs/publication.md)、[禅道 MCP](docs/zentao.md)。实例与仓库按业务项目配置，运行状态读取实际证据，不固化在规则中。

正式评审使用已提交输入和不可变归档；批准、上线验证、同步、指派、接收、实现与验收分别记录。静态包提供一个原型与需求评审地址，localhost 仅供本机。没有目标或权限时完成独立本地工作并报告缺项，不宣称远端成功。

## 旧锁与新版

`toolkit bootstrap` 是显式修复管理型引导器，保留旧锁和包；`toolkit bundle` 是明确更新项目工具锁，保留旧版本依据。旧 0.1 修复后仍只有原能力，0.2 的上下文与新默认模板需要显式升级。详见 [版本恢复](docs/user-guide.md#独立迁出与工具版本)。

不要按父目录文件存在性、临时环境变量或缓存 stamp 绕过锁定校验。独立项目的说明和能力文件来自自身锁定归档，不要求原机器绝对路径或全局配置。

## 验证

```sh
npm test
node scripts/verify-demo.mjs
```

测试按受影响范围执行；浏览器、模拟和真实外部结果分别说明。手册还需由无历史上下文、无原生 Skills 的接手者在临时项目中演练。实际完成范围见 [验证记录](docs/verification.md)，不能以文件存在或命令启动替代完成证据。
