import {mkdir,open,readFile,unlink} from 'node:fs/promises';
import {join,relative} from 'node:path';
import {hostname} from 'node:os';
import {hash,readJson,writeJson,confined} from '../../lib/core.mjs';

export const PRODUCT_FIELDS=Object.freeze(['title','description','acceptanceCriteria','reviewUrl']);
export const now=()=>new Date().toISOString();
export function productFields(fields){return Object.fromEntries(PRODUCT_FIELDS.filter(k=>fields[k]!==undefined).map(k=>[k,structuredClone(fields[k])]))}
export function externalKey({projectId,changeId,reqId,itemType='story',itemKey='main'}){
  for(const [k,v]of Object.entries({projectId,changeId,reqId,itemType,itemKey}))if(typeof v!=='string'||!v||/[\r\n/]/.test(v))throw Error(`交接业务键 ${k} 无效`);
  return [projectId,changeId,reqId,itemType,itemKey].join('/');
}
export function marker(key){return `<!-- product-workflow:${Buffer.from(key).toString('base64url')} -->`}
export function parseMarker(value=''){const m=value.match(/<!-- product-workflow:([\w-]+) -->/);return m?Buffer.from(m[1],'base64url').toString():null}
export function normalizedRemote(remote){return productFields(remote.fields||remote)}
export function matchesRemote(remote,item){return remote&&remote.id!==undefined&&remote.id!==null&&String(remote.id).length>0&&hash(normalizedRemote(remote))===hash(productFields(item.fields))&&(remote.externalKey===undefined||remote.externalKey===item.externalKey)}
export async function deliveryPaths(ctx,simulation=false){
  const rel=relative(ctx.root,ctx.paths.delivery),root=await confined(ctx.root,rel);
  const base=await confined(ctx.root,join(rel,...(simulation?['simulation']:[])));
  const mapping=await confined(ctx.root,join(rel,...(simulation?['simulation']:[]),'mapping.json'));
  return {root,base,mapping};
}
export async function loadMapping(ctx,simulation=false){const p=await deliveryPaths(ctx,simulation);return readJson(p.mapping,{schemaVersion:1,projectId:ctx.projectId,simulation,entries:{}})}
export async function saveMapping(ctx,mapping){if(mapping.projectId!==ctx.projectId)throw Error('映射项目不符');const p=await deliveryPaths(ctx,mapping.simulation);return writeJson(p.mapping,mapping)}
export function targetFingerprint(ctx){const c=ctx.config.zentao||{},m=c.mcp||{};let endpoint=null;try{const u=new URL(m.url);endpoint=u.origin+u.pathname}catch{}return hash({provider:c.provider||'mcp',baseUrl:c.baseUrl||null,productId:c.productId||null,projectId:c.projectId||null,executionId:c.executionId||null,mcp:{url:endpoint,command:m.command||null,args:m.args||[]}})}
export async function withDeliveryLock(ctx,fn){
  const {root}=await deliveryPaths(ctx);await mkdir(root,{recursive:true});const file=join(root,'.sync.lock');
  let handle;
  for(let i=0;i<2;i++){
    try{handle=await open(file,'wx');break}catch(e){
      if(e.code!=='EEXIST')throw e;
      let owner;try{owner=JSON.parse(await readFile(file,'utf8'))}catch{throw Error('交接锁不完整，请核对不存在运行中的同步后移除 .sync.lock')}
      let alive=true;if(owner.host===hostname()&&Number.isInteger(owner.pid)){try{process.kill(owner.pid,0)}catch(err){if(err.code==='ESRCH')alive=false}}
      if(alive)throw Error('该项目已有禅道同步正在执行');
      await unlink(file);
    }
  }
  if(!handle)throw Error('无法取得交接同步锁');
  await handle.writeFile(JSON.stringify({pid:process.pid,host:hostname(),createdAt:now()}));
  try{return await fn()}finally{await handle.close();await unlink(file).catch(e=>{if(e.code!=='ENOENT')throw e})}
}

export async function approvedReview(ctx,id,provided,{draft=false}={}){
  if(typeof id!=='string'||!/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,119}$/.test(id))throw Error('评审 ID 无效');
  const review=provided||await (await import('../../lib/reviews.mjs')).readReview(ctx,id);
  const m=review.manifest,a=review.approval;
  if(!m||m.projectId!==ctx.projectId||(m.reviewId||m.id)!==id||!review.document)throw Error('评审版本与项目不匹配');
  if(m.requirementHash!==hash(review.document))throw Error('冻结需求内容校验不符');
  const approved=m.kind==='formal'&&a?.decision==='approved'&&a.reviewId===id&&a.manifestHash===m.manifestHash&&a.actor;
  if(!draft&&!approved)throw Error('正式交接需要已批准的正式冻结基线');
  return {...review,approved:Boolean(approved)};
}
