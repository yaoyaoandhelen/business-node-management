import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import {StdioClientTransport,getDefaultEnvironment} from '@modelcontextprotocol/sdk/client/stdio.js';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {productFields} from './shared.mjs';

const ENV=/^[A-Za-z_][A-Za-z0-9_]*$/;
const clientVersion=JSON.parse(readFileSync(new URL('../../package.json',import.meta.url),'utf8')).version;
const FORBIDDEN_WRITE_FIELDS=new Set(['assignedto','assignee','owner','status','estimate','consumed','left','deadline','startdate','enddate','executionstatus']);
const own=(value,key)=>value!==null&&typeof value==='object'&&Object.hasOwn(value,key);
function invalid(message){const error=Error(message);error.definitive=true;return error}
function config(ctx){return ctx.config.zentao?.mcp||{}}
function credentials(ctx){
  const c=config(ctx);if(!c.credentialsFile)return {token:null,missing:[],error:null};
  try{
    const value=JSON.parse(readFileSync(resolve(ctx.root,c.credentialsFile),'utf8'));
    if(value.site!==ctx.config.zentao?.baseUrl)return {token:null,missing:[],error:'zentao.mcp.credentialsFile.site (must match zentao.baseUrl)'};
    if(typeof value.token!=='string'||!value.token.trim())return {token:null,missing:['zentao.mcp.credentialsFile.token'],error:null};
    return {token:value.token,missing:[],error:null};
  }catch{return {token:null,missing:['zentao.mcp.credentialsFile.token (file unavailable)'],error:null}}
}
function secretValues(ctx){const c=config(ctx),values=[credentials(ctx).token];for(const value of [...Object.values(c.headersEnv||{}),...Object.values(c.env||{})])if(typeof value==='string'&&ENV.test(value)){const secret=process.env[value];if(secret){values.push(secret);if(/^Bearer /i.test(secret))values.push(secret.slice(7))}}return [...new Set(values.filter(Boolean))].sort((a,b)=>b.length-a.length)}
function redact(value,secrets){if(typeof value==='string')return secrets.reduce((s,secret)=>s.split(secret).join('[redacted]'),value);if(Array.isArray(value))return value.map(v=>redact(v,secrets));if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,redact(v,secrets)]));return value}
function types(c){return Object.keys(c.tools||{}).filter(k=>k!=='status'&&c.tools[k]&&typeof c.tools[k]==='object')}
function envBindings(value,label,missing){
  const result={};
  if(value===undefined)return result;
  if(!value||typeof value!=='object'||Array.isArray(value)){missing.push(label);return result}
  for(const [key,name]of Object.entries(value)){
    if(typeof name!=='string'||!ENV.test(name))missing.push(`${label}.${key} (environment variable name)`);
    else if(!process.env[name])missing.push(`env.${name}`);
    else result[key]=process.env[name];
  }
  return result;
}

/** Transport/auth discovery needs no product IDs or write mappings. Never derives a URL from baseUrl. */
export function missingMcpConfig(ctx,{forWrite=true}={}){
  const c=config(ctx),missing=[];
  if(!c.url&&!c.command)missing.push('zentao.mcp.url|command');
  if(c.url&&c.command)missing.push('zentao.mcp.transport (choose url or command)');
  if(c.url){try{const url=new URL(c.url);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw Error()}catch{missing.push('zentao.mcp.url (HTTP(S) endpoint without inline credentials)')}}
  if(c.command&&(typeof c.command!=='string'||!c.command.trim()))missing.push('zentao.mcp.command');
  if(c.args!==undefined&&(!Array.isArray(c.args)||c.args.some(v=>typeof v!=='string')))missing.push('zentao.mcp.args');
  if(c.timeoutMs!==undefined&&(!Number.isSafeInteger(c.timeoutMs)||c.timeoutMs<100||c.timeoutMs>30000))missing.push('zentao.mcp.timeoutMs (100..30000)');
  envBindings(c.headersEnv,'zentao.mcp.headersEnv',missing);envBindings(c.env,'zentao.mcp.env',missing);
  const credential=credentials(ctx);if(credential.error)missing.push(credential.error);if(forWrite)missing.push(...credential.missing);
  if(forWrite){
    const itemTypes=types(c);if(!itemTypes.length)itemTypes.push('story');
    for(const type of itemTypes)for(const op of ['create','update','read']){
      const mapping=c.tools?.[type]?.[op];
      if(!mapping?.name||typeof mapping.name!=='string')missing.push(`zentao.mcp.tools.${type}.${op}.name`);
      if(op==='read'&&mapping?.name&&mapping.readOnly!==true)missing.push(`zentao.mcp.tools.${type}.read.readOnly`);
    }
  }
  return [...new Set(missing)];
}

function pathValue(value,path){
  if(path==='$'||path===''||path===undefined)return value;
  if(typeof path!=='string')throw invalid('MCP 字段映射必须使用明确的点路径');
  for(const key of path.replace(/^\$\./,'').split('.')){
    if(['__proto__','prototype','constructor'].includes(key)||!own(value,key))throw invalid(`MCP 字段映射路径不存在: ${path}`);
    value=value[key];
  }
  return value;
}
function template(value,context){
  if(typeof value==='string'){
    const exact=value.match(/^\$\{([^}]+)\}$/);if(exact)return structuredClone(pathValue(context,exact[1]));
    return value.replace(/\$\{([^}]+)\}/g,(_,path)=>{const part=pathValue(context,path);if(part!==null&&typeof part==='object')throw invalid('MCP 混合字符串模板不能隐式序列化对象');return String(part??'')});
  }
  if(Array.isArray(value))return value.map(v=>template(v,context));
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,template(v,context)]));
  return value;
}
function checkWriteFields(value){
  if(!value||typeof value!=='object')return;
  for(const [key,part]of Object.entries(value)){if(FORBIDDEN_WRITE_FIELDS.has(key.toLowerCase()))throw invalid(`MCP 产品同步不能覆盖执行字段 ${key}`);checkWriteFields(part)}
}
function contextFor(item={},remoteId){
  const clean={};for(const key of ['projectId','changeId','reqId','itemType','itemKey','externalKey','target'])if(item[key]!==undefined)clean[key]=structuredClone(item[key]);
  if(item.fields)clean.fields=productFields(item.fields);
  return {item:clean,remoteId,externalKey:item.externalKey,itemType:item.itemType};
}
function argumentsFor(mapping,context,operation){
  const fallback=operation==='create'?context.item:operation==='update'?{...context.item,remoteId:context.remoteId}:operation==='read'?{itemType:context.itemType,remoteId:context.remoteId}:operation==='findByExternalKey'?{itemType:context.itemType,externalKey:context.externalKey}:{};
  const args=mapping.arguments===undefined?fallback:template(mapping.arguments,context);
  if(!args||typeof args!=='object'||Array.isArray(args))throw invalid('MCP 工具参数必须是对象');
  if(['create','update'].includes(operation))checkWriteFields(args);
  return args;
}
function unpack(result){
  if(result.isError)throw Error('MCP 工具返回执行错误，写入结果需要核对');
  if(result.structuredContent!==undefined)return result.structuredContent;
  const content=result.content?.filter(x=>x.type==='text')||[];
  if(content.length!==1)throw Error('MCP 工具需要返回 structuredContent 或单个 JSON 文本结果');
  try{return JSON.parse(content[0].text)}catch{return content[0].text}
}
function normalize(value,mapping,operation,remoteId){
  value=mapping.result?.path?pathValue(value,mapping.result.path):value;
  if(operation==='findByExternalKey'){
    if(!Array.isArray(value))throw Error('MCP 外部键查询必须返回完整匹配数组');
    return value.map(v=>normalize(v,{...mapping,result:{...mapping.result,path:undefined}},'read'));
  }
  if(value===null&&operation==='read')return null;
  if(!value||typeof value!=='object'||Array.isArray(value))throw Error('MCP 结果不符合已登记的对象契约');
  const result=mapping.result||{},id=result.id?pathValue(value,result.id):value.id??(operation==='update'?remoteId:undefined);
  if(id===undefined||id===null||String(id)==='')throw Error('MCP 结果缺少可核对远端 ID');
  if(['create','update'].includes(operation))return {id:String(id)};
  const externalKey=result.externalKey?pathValue(value,result.externalKey):value.externalKey;
  let fields;if(result.fields)fields=Object.fromEntries(Object.entries(result.fields).map(([name,path])=>[name,pathValue(value,path)]));else fields=value.fields;
  if(!fields||typeof fields!=='object'||Array.isArray(fields))throw Error('MCP 回读未提供已登记的产品字段');
  const normalized=productFields(fields);
  for(const name of result.parseJson||[]){if(!Object.hasOwn(normalized,name))throw Error('MCP parseJson 指向未登记的产品字段');normalized[name]=JSON.parse(normalized[name])}
  if(typeof normalized.title!=='string'||typeof normalized.description!=='string'||!Array.isArray(normalized.acceptanceCriteria)||typeof normalized.reviewUrl!=='string')throw Error('MCP 回读产品字段类型不兼容，需要显式实例映射');
  return {id:String(id),...(externalKey===undefined?{}:{externalKey}),fields:normalized};
}

async function toolsOn(client,timeout){
  const tools=[],seen=new Set();let cursor;
  do{const page=await client.listTools(cursor?{cursor}:{},{timeout});tools.push(...page.tools);cursor=page.nextCursor;if(cursor){if(seen.has(cursor)||seen.size>=19)throw Error('MCP 工具清单分页未能完整确认');seen.add(cursor)}}while(cursor);
  return tools;
}
async function connection(ctx,options,callback){
  const missing=missingMcpConfig(ctx,{forWrite:false});if(missing.length)throw invalid('MCP 连接配置缺失: '+missing.join(', '));
  const c=config(ctx),timeout=c.timeoutMs||10000,headers=envBindings(c.headersEnv,'zentao.mcp.headersEnv',[]),environment=envBindings(c.env,'zentao.mcp.env',[]),credential=credentials(ctx);
  if(credential.token&&!Object.keys(headers).some(k=>k.toLowerCase()==='token'))headers.Token=credential.token;
  const client=new Client({name:'product-workflow-zentao',version:clientVersion},{capabilities:{}});
  const transport=c.url?new StreamableHTTPClientTransport(new URL(c.url),{requestInit:{headers,redirect:'error'},...(options.fetchImpl?{fetch:options.fetchImpl}:{}),reconnectionOptions:{initialReconnectionDelay:100,maxReconnectionDelay:100,reconnectionDelayGrowFactor:1,maxRetries:0}}):new StdioClientTransport({command:c.command,args:c.args||[],env:{...getDefaultEnvironment(),...environment},cwd:ctx.root,stderr:'pipe'});
  transport.stderr?.resume();
  try{await client.connect(transport,{timeout});const tools=await toolsOn(client,timeout);return await callback(client,tools,timeout)}finally{await client.close().catch(()=>{});await transport.close().catch(()=>{})}
}
function mappingFor(c,itemType,operation){
  const mapping=operation==='status'?c.tools?.status:c.tools?.[itemType]?.[operation];
  if(!mapping||typeof mapping.name!=='string'||!mapping.name.trim())throw invalid(`未登记 MCP ${itemType||''} ${operation} 工具映射`);
  if(['read','findByExternalKey','status'].includes(operation)&&mapping.readOnly!==true)throw invalid(`MCP ${operation} 映射必须明确 readOnly:true`);
  if(operation==='findByExternalKey'&&mapping.complete!==true)throw invalid('MCP 外部键查询尚未确认完整可靠，不可据此重建');
  return mapping;
}
function listedTool(tools,mapping,readOnly){
  const tool=tools.find(t=>t.name===mapping.name);if(!tool)throw invalid(`映射的 MCP 工具未在 tools/list 中发现: ${mapping.name}`);
  if(readOnly&&(tool.annotations?.readOnlyHint===false||tool.annotations?.destructiveHint===true))throw invalid('MCP 工具声明与只读映射冲突，已阻止调用');
  return tool;
}

/** Uses MCP initialize/tools/list only unless an explicitly read-only status mapping is requested. */
export async function discoverMcpTools(ctx,{callStatus=false,...options}={}){
  const missing=missingMcpConfig(ctx,{forWrite:false});
  if(missing.length)return {provider:'mcp',status:'pending-configuration',connected:false,readOnly:true,missing,tools:[]};
  try{return await connection(ctx,options,async(client,tools,timeout)=>{
    let statusResult={status:'not-requested'};
    if(callStatus){
      if(!config(ctx).tools?.status)statusResult={status:'not-configured'};
      else{const mapping=mappingFor(config(ctx),null,'status');listedTool(tools,mapping,true);const args=argumentsFor(mapping,{},'status');statusResult={status:'read',result:unpack(await client.callTool({name:mapping.name,arguments:args},undefined,{timeout}))}}
    }
    return redact({provider:'mcp',status:'connected',connected:true,readOnly:true,transport:config(ctx).url?'streamable-http':'stdio',server:client.getServerVersion(),missing:missingMcpConfig(ctx),tools:tools.map(({name,description,inputSchema,outputSchema,annotations})=>({name,description,inputSchema,...(outputSchema?{outputSchema}:{}),...(annotations?{annotations}:{})})),statusResult},secretValues(ctx));
  })}catch(error){return redact({provider:'mcp',status:'connection-failed',connected:false,readOnly:true,missing:[],tools:[],error:error.definitive?error.message:'MCP 初始化、工具发现或只读状态调用失败；请检查端点、鉴权及服务端日志'},secretValues(ctx))}
}

/** Synchronous adapter construction; transport is opened/closed for each operation. */
export function createMcpAdapter(ctx,options={}){
  const c=config(ctx),itemTypes=types(c),readBack=itemTypes.length>0&&itemTypes.every(type=>c.tools[type].read?.name&&c.tools[type].read.readOnly===true);
  async function invoke(itemType,operation,context){
    const mapping=mappingFor(c,itemType,operation),args=argumentsFor(mapping,context,operation);let called=false;
    if(['create','update'].includes(operation)){const missing=missingMcpConfig(ctx);if(missing.length)throw invalid('MCP 写入配置缺失: '+missing.join(', '))}
    try{return await connection(ctx,options,async(client,tools,timeout)=>{listedTool(tools,mapping,['read','findByExternalKey'].includes(operation));called=true;const result=unpack(await client.callTool({name:mapping.name,arguments:args},undefined,{timeout}));return normalize(result,mapping,operation,context.remoteId)})}
    catch(error){if(error.definitive)throw error;const safe=Error(called?'MCP 工具请求结果未知，需要按映射核对':'MCP 连接或工具发现失败，尚未发起业务写入');if(!called)safe.definitive=true;throw safe}
  }
  return {kind:'mcp',isSimulation:false,authConfigured:missingMcpConfig(ctx,{forWrite:false}).length===0,capabilities:{readBack,stableKeyLookup:readBack&&itemTypes.every(type=>c.tools[type].findByExternalKey?.complete===true&&c.tools[type].findByExternalKey.readOnly===true),itemTypes},
    create:item=>invoke(item.itemType,'create',contextFor(item)),
    update:(item,remoteId)=>invoke(item.itemType,'update',contextFor(item,remoteId)),
    read:(itemType,remoteId)=>invoke(itemType,'read',{itemType,remoteId}),
    findByExternalKey:(itemType,externalKey)=>invoke(itemType,'findByExternalKey',{itemType,externalKey}),
    discover:options=>discoverMcpTools(ctx,options)
  };
}
