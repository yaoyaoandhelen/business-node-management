---
name: github-pages-review
description: 为指定业务项目生成原型与需求统一评审快照、保留历史版本，并发布或验证该项目自己的GitHub Pages站点。用于原型评审交付，不用于通用网站托管迁移。
---

读取项目配置、需求校验结果、现有归档与评审记录，具体命令见 [发布说明](../../../docs/publication.md)。仓库和 Pages 地址按项目配置，不默认一个全局仓库。

先完成可复核静态包：

```sh
node tooling/run.mjs review preview --project project.config.yaml
node tooling/run.mjs review freeze --project project.config.yaml
node tooling/run.mjs review export --project project.config.yaml
```

本地预览允许未提交源码；正式冻结要求登记输入已提交，manifest 同时关联需求和源码。批准必须来自明确决定，单独记录 actor、decision 和快照，不推测其他评审者同意。

按项目配置安装 CI 模板、打包锁定工具，再根据已有发布授权执行发布。未指定仓库时保留本地包并指出缺项，不新建猜测仓库。发布重试复用同一快照，不重新创建交付版本。

统一入口默认展示完整原型，可进入模块需求说明。校验根路径与仓库子路径，关闭开发服务后静态包应仍可用。每次发布从持久归档组装全部保留快照，旧链接和内容不能改变。

仅在取得实际 deployment URL 并回读目标 reviewId、manifest hash 及关键资源后报告上线。CI成功、HTTP200、localhost 或静态包导出各自都不足以证明目标版本在线。旧缓存或错误版本应判验证失败。
