import {loadProject,readState} from '../../lib/core.mjs';
import {readReview} from '../../lib/reviews.mjs';
import {verifyPages} from './index.mjs';
import {readdir} from 'node:fs/promises';
import {join} from 'node:path';
const args=Object.fromEntries(process.argv.slice(2).reduce((pairs,value,i,all)=>value.startsWith('--')?[...pairs,[value.slice(2),all[i+1]]]:pairs,[]));
try{
 const ctx=await loadProject(args.project);const state=await readState(ctx);const change=state.changes[state.activeChangeId||ctx.config.activeChangeId]||{};
 const current=args.review||change.latestReviewId||change.previewReviewId;if(!current)throw Error('没有明确的目标评审版本');
 const checked=[await verifyPages(ctx,{reviewId:current,url:args.url})];
 let entries=[];try{entries=await readdir(join(ctx.paths.archive,'review'))}catch(e){if(e.code!=='ENOENT')throw e}
 const historical=entries.filter(value=>!value.startsWith('.')&&value!==current).sort()[0];if(historical){await readReview(ctx,historical);checked.push(await verifyPages(ctx,{reviewId:historical,url:args.url,record:false}))}
 process.stdout.write(JSON.stringify({status:'verified',actualDeploymentURL:args.url,reviews:checked},null,2)+'\n');
}catch(error){process.stderr.write(error.message+'\n');process.exitCode=1}
