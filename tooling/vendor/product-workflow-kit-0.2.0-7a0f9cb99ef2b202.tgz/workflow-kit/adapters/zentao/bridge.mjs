/** Allows an already authorized official MCP/API connection to implement this contract. */
export function createBridgeAdapter(connection){
  for(const name of ['create','update','read'])if(typeof connection?.[name]!=='function')throw Error(`禅道连接桥缺少 ${name}`);
  const capabilities={...connection.capabilities};
  if(!capabilities.readBack||!Array.isArray(capabilities.itemTypes)||!capabilities.itemTypes.length)throw Error('连接桥必须声明回读和对象类型能力');
  if(capabilities.stableKeyLookup&&typeof connection.findByExternalKey!=='function')throw Error('连接桥未实现声明的外部键核对能力');
  return {kind:'bridge',isSimulation:connection.isSimulation===true,capabilities,create:connection.create.bind(connection),update:connection.update.bind(connection),read:connection.read.bind(connection),findByExternalKey:connection.findByExternalKey?.bind(connection)};
}
