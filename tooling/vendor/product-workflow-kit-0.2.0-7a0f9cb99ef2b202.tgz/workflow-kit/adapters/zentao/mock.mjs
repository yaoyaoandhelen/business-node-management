import {normalizedRemote,productFields} from './shared.mjs';

/** In-memory remote with deliberate, observable faults; never contacts a server. */
export function createMemoryAdapter({seed=[],faults=[],stableKeyLookup=true}={}){
  const objects=new Map(seed.map(x=>[String(x.id),structuredClone(x)]));
  const calls=[],counts={},remaining=faults.map(x=>({...x}));let next=1;
  for(const id of objects.keys())if(/^\d+$/.test(id))next=Math.max(next,Number(id)+1);
  function fault(op,phase){const at=counts[op];const f=remaining.find(f=>!f.used&&f.operation===op&&(f.at||1)===at&&(f.phase||'before')===phase);if(f){f.used=true;const e=Error(f.message||`模拟 ${op} ${phase} 失败`);e.code=f.code||'ETIMEDOUT';e.definitive=Boolean(f.definitive);throw e}}
  function begin(op,info){counts[op]=(counts[op]||0)+1;calls.push({...structuredClone(info),operation:op});fault(op,'before')}
  return {
    kind:'simulation',isSimulation:true,
    capabilities:{readBack:true,stableKeyLookup,itemTypes:['story','task']},
    calls,objects,
    snapshot:()=>[...objects.values()].map(x=>structuredClone(x)),
    async create(item){begin('create',item);const id=String(next++);objects.set(id,{id,itemType:item.itemType,externalKey:item.externalKey,target:structuredClone(item.target),fields:productFields(item.fields),assignedTo:null,status:'wait',consumed:0});fault('create','after');return {id}},
    async update(item,id){begin('update',{...item,id});const current=objects.get(String(id));if(!current){const e=Error('模拟远端对象不存在');e.definitive=true;throw e}current.fields={...current.fields,...productFields(item.fields)};fault('update','after');return {id:String(id)}},
    async read(itemType,id){begin('read',{itemType,id});const value=objects.get(String(id));if(!value||value.itemType!==itemType)return null;fault('read','after');return structuredClone(value)},
    async findByExternalKey(itemType,key){begin('lookup',{itemType,key});if(!stableKeyLookup)throw Error('不支持可靠外部键核对');const result=[...objects.values()].filter(v=>v.itemType===itemType&&v.externalKey===key);fault('lookup','after');return structuredClone(result)},
    editExecution(id,fields){const value=objects.get(String(id));if(!value)throw Error('对象不存在');Object.assign(value,structuredClone(fields));return normalizedRemote(value)}
  };
}
export const createMockAdapter=createMemoryAdapter;
