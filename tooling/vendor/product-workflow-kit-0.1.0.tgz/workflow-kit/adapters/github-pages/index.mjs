import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {join,relative} from 'node:path';
import {randomUUID} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readReview,exportSite} from '../../lib/reviews.mjs';
import {readJson,writeJson,readState,writeState,hash,confined,kitRoot} from '../../lib/core.mjs';
const exec=promisify(execFile);
function configured(value){return typeof value==='string'&&value.trim().length>0}
export function githubStatus(ctx){const config=ctx.config.github||{};const missing=['owner','repository','branch','basePath'].filter(key=>!configured(config[key])).map(key=>'github.'+key);return {configured:!missing.length,missing,target:missing.length?null:`${config.owner}/${config.repository}`,online:false}}
async function publicationFile(ctx,id){return confined(ctx.root,relative(ctx.root,join(ctx.paths.reviews,id,'publication.json')))}
async function appendAttempt(ctx,id,attempt){const file=await publicationFile(ctx,id);const record=await readJson(file,{schemaVersion:1,projectId:ctx.projectId,reviewId:id,attempts:[]});record.attempts.push(attempt);await writeJson(file,record);return record}
function deploymentReviewURL(url,manifest){let base=new URL(url);if(!['https:','http:'].includes(base.protocol)||base.username||base.password)throw Error('发布URL必须是HTTP(S)地址且不含凭据');base.hash='';base.search='';if(!base.pathname.endsWith('/'))base.pathname+='/';const suffix=manifest.kind==='preview'?'preview/':`review/${manifest.reviewId}/`;return base.pathname.endsWith('/'+suffix)?base:new URL(suffix,base)}
async function get(fetchImpl,url){const response=await fetchImpl(url,{redirect:'follow',signal:AbortSignal.timeout(20000),headers:{'Cache-Control':'no-cache'}});if(!response.ok)throw Error(`远端资源读取失败 HTTP ${response.status}: ${url}`);return Buffer.from(await response.arrayBuffer())}

/** Validate actual remote identity, not merely HTTP success. Does not claim an Actions deployment. */
export async function verifyPages(ctx,{reviewId,url,fetchImpl=globalThis.fetch,record=true}={}){
 const review=await readReview(ctx,reviewId);if(!url)throw Error('远端验证需要实际 deployment URL，不能以本机预览代替');
 const target=deploymentReviewURL(url,review.manifest);if(['localhost','127.0.0.1','[::1]'].includes(target.hostname))throw Error('localhost 仅供本机验证，不能登记为团队在线地址');
 const attempt={id:randomUUID(),type:'verify',reviewId,manifestHash:review.manifest.manifestHash,startedAt:new Date().toISOString(),url:target.href};
 try{
  const remote=JSON.parse((await get(fetchImpl,new URL('manifest.json',target).href)).toString('utf8'));const {manifestHash,...body}=remote;
  if(remote.projectId!==ctx.projectId||remote.reviewId!==reviewId||manifestHash!==review.manifest.manifestHash||hash(body)!==manifestHash)throw Error('远端版本或 manifest hash 不匹配');
  const essential=new Set(['index.html','snapshot.json']);
  const snapshot=await readJson(join(review.directory,'snapshot.json'));
  for(const page of snapshot.project.pages){let path=page.path.replace(/^\.\//,'').split(/[?#]/)[0];if(!path||path==='.')path='index.html';else if(path.endsWith('/'))path+='index.html';essential.add('prototype/'+path)}
  // Include entry assets referenced by both the Studio and prototype HTML.
  for(const file of [...essential].filter(path=>path.endsWith('.html'))){const html=await readFile(join(review.directory,file),'utf8');for(const match of html.matchAll(/(?:src|href)=["']([^"'#]+)["']/g)){const href=match[1];if(/^(?:https?:|data:|\/\/)/i.test(href))continue;const parsed=new URL(href,new URL(file,target));if(parsed.origin!==target.origin||!parsed.pathname.startsWith(target.pathname))throw Error('关键资源路径超出当前评审');essential.add(decodeURIComponent(parsed.pathname.slice(target.pathname.length)))}}
  const verified=[];for(const path of essential){if(!Object.hasOwn(review.manifest.files,path))throw Error('关键资源未登记到manifest: '+path);const bytes=await get(fetchImpl,new URL(path,target).href);if(hash(bytes)!==review.manifest.files[path])throw Error('远端关键资源hash不匹配: '+path);verified.push(path)}
  Object.assign(attempt,{status:'verified',verifiedAt:new Date().toISOString(),resources:verified});if(record)await appendAttempt(ctx,reviewId,attempt);
  if(record){const state=await readState(ctx);const change=state.changes[review.manifest.changeId];if(change){change.publication={status:'verified',reviewId,manifestHash:review.manifest.manifestHash,url:target.href,verifiedAt:attempt.verifiedAt};await writeState(ctx,state)}}
  return {...attempt,online:true};
 }catch(error){Object.assign(attempt,{status:'verification_failed',error:error.message,finishedAt:new Date().toISOString()});if(record)await appendAttempt(ctx,reviewId,attempt);throw Object.assign(error,{publication:attempt})}
}

/** Start the registered Actions workflow. Its eventual deployment must be verified separately. */
export function createGhAdapter({run=exec}={}){return {
 async deploy({config,reviewId,requestId}){const repo=`${config.owner}/${config.repository}`;await run('gh',['workflow','run','pages.yml','--repo',repo,'--ref',config.branch,'-f',`review_id=${reviewId}`,'-f',`request_id=${requestId}`],{timeout:30000,maxBuffer:1024*1024});return {status:'pending',requestId,workflowUrl:`https://github.com/${repo}/actions/workflows/pages.yml`}}
}}

/** Export is always local. Remote execution occurs only with execute:true. */
export async function publishPages(ctx,{reviewId,execute=false,adapter,fetchImpl=globalThis.fetch}={}){
 const review=await readReview(ctx,reviewId),site=await exportSite(ctx),target=githubStatus(ctx);
 if(!target.configured)return {...site,status:'not_configured',missing:target.missing,reviewId,manifestHash:review.manifest.manifestHash,online:false};
 if(!execute)return {...site,status:'prepared',target:target.target,reviewId,manifestHash:review.manifest.manifestHash,online:false};
 const attempt={id:randomUUID(),type:'deploy',reviewId,manifestHash:review.manifest.manifestHash,startedAt:new Date().toISOString(),target:target.target,status:'intent'};await appendAttempt(ctx,reviewId,attempt);
 try{
  const result=await (adapter||createGhAdapter()).deploy({ctx,config:ctx.config.github,reviewId,requestId:attempt.id,directory:site.output,manifest:review.manifest});
  if(result.status==='pending'){const pending={...attempt,status:'deployment_pending',workflowUrl:result.workflowUrl,requestId:result.requestId};await appendAttempt(ctx,reviewId,pending);return {...pending,online:false}}
  if(result.status!=='success'||!result.url||!result.deploymentId)throw Error('发布适配器没有提供成功部署、实际URL和deploymentId证据');
  const deployed={...attempt,status:'deployed_unverified',deploymentId:result.deploymentId,url:result.url,workflowUrl:result.workflowUrl,finishedAt:new Date().toISOString()};await appendAttempt(ctx,reviewId,deployed);
  const verification=await verifyPages(ctx,{reviewId,url:result.url,fetchImpl});
  return {...deployed,status:'verified',verification,online:true};
 }catch(error){const failed={...attempt,status:'deployment_failed',error:error.message,finishedAt:new Date().toISOString()};await appendAttempt(ctx,reviewId,failed);throw Object.assign(error,{publication:failed})}
}

/** Install a portable template; existing workflows are never silently overwritten. */
export async function installPagesTemplate(ctx){const output=await confined(ctx.root,'.github/workflows/pages.yml');await mkdir(join(ctx.root,'.github/workflows'),{recursive:true});let template=await readFile(join(kitRoot,'templates/pages.yml'),'utf8');template=template.replace('__PROJECT_BRANCH__',JSON.stringify(ctx.config.github?.branch||'__CONFIGURE_PROJECT_BRANCH__'));await writeFile(output,template,{flag:'wx'});const restore=await confined(ctx.root,'tooling/restore.mjs');await mkdir(join(ctx.root,'tooling'),{recursive:true});await writeFile(restore,await readFile(join(kitRoot,'templates/restore.mjs')),{flag:'wx'});return {path:output,restore,...githubStatus(ctx)}}
