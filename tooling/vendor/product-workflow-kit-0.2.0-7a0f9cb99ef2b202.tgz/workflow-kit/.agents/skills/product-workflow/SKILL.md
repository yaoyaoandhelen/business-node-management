---
name: product-workflow
description: 在已配置业务项目中推进需求分析、HTML原型、在线评审、禅道交接和研发协同，或继续中断的产品设计工作。用于阶段衔接和产物检查，不用于需求池或直接开发生产业务系统。
---

先读 [Agent 协议](../../../docs/agent-protocol.md)、[工作流](../../../docs/workflow.md) 与 [使用手册](../../../docs/user-guide.md)。本文件可以直接读取，不要求客户端自动注册；命令核验状态以手册为准。

先区分框架维护与业务工作。框架使用工作空间根 OpenSpec；业务先定位项目，再读其 AGENTS.md、配置、工具锁和该版本上下文。用户明确目标优先；歧义先列候选，不默认示例、不记录全局当前项目。

对支持 0.2 能力的锁定项目，在业务项目根使用只读入口：

```sh
node tooling/run.mjs workflow context --project project.config.yaml --intent resume
node tooling/run.mjs workflow next --project project.config.yaml --intent resume
```

旧工具缺命令时按手册恢复或明确升级，不能用新工具冒充旧锁。核对 readFiles、来源、阶段、证据、checkpoint、缺项和写入范围；状态/交接过期时重新评估，不因“继续”重新初始化或执行旧 nextActions。

将用户意图结合前置条件路由：

- 需求分析：按共享阶段说明与需求模型分析目标、范围、角色、流程和验收条件。prd-writer 可按可用性增强；没有原生注册不阻断基础分析。详细规则回到唯一 JSON，分析记录只引用。
- 原型、交互或评审修改：读取 [html-product-design](../html-product-design/SKILL.md)。已有预览不触发自动发布。
- 快照、评审站点或部署：读取 [github-pages-review](../github-pages-review/SKILL.md)。
- 交接、进度、澄清或范围变更：读取 [zentao-handoff](../zentao-handoff/SKILL.md)。

上下文默认只读；只有用户的实际工作请求决定写入范围。声明项目、change、允许文件和共享提交责任，按协议保存实际证据及必要交接。缺业务决定时给出候选和缺项，不编造确认。

保持 Studio 全部约束和生命周期独立语义。需求保存事件不自动执行 Codex 或远端写入；操作失败或结果未知如实记录。发布和业务同步按已有授权及明确目标执行，准备产物不等于已发送或已接收。阶段 7 仍为预留。
