# 产品设计工作流使用手册

本手册面向产品负责人及接手工作的 Agent。可以用自然语言提出任务，也可以直接执行 CLI；两种方式使用相同的项目配置、需求源和证据。先了解 [工作流职责](workflow.md) 与 [协作协议](agent-protocol.md)。

**本手册对应 0.2。** project list/import、workflow context/next/checkpoint、toolkit bootstrap 及空白初始化已完成本地与隔离环境核验，证据和未测范围见[验证记录](verification.md)。已有命令仍以所运行版本的 help 和实际结果为准；锁定 0.1 的项目不会因为阅读本手册自动拥有新命令。

## 环境、位置与占位符

需要 Node.js 22.12 或更新版本、npm，以及可读写的项目目录。正式冻结需要独立 Git 仓库和已提交业务输入；GitHub Pages 需要真实仓库、Actions/Pages 权限和发布连接；禅道需要明确的 MCP 服务与项目目标。后两项未配置不阻塞本地设计、静态导出和交接预演。

本手册明确区分命令位置：

- **工作空间根**：含 `workflow-kit/` 和 `projects/` 的目录，用 `node workflow-kit/bin/pwf.mjs` 发现项目、创建/导入项目和维护工具。
- **业务项目根**：含 `project.config.yaml` 的目录，业务动作统一用 `node tooling/run.mjs`，加载该项目的锁定版本。
- `PROJECT_DIR`、`PROJECT_ID`、`CHANGE_ID`、`REVIEW_ID`、`PLAN_ID`、`IMPACT_ID` 等大写值都需要替换，不是默认值。目录名与 projectId 不一定相同。
- 本机服务地址由 `studio dev` 的实际输出和 `.local/project.local.yaml` 决定。不要照抄旧聊天中的端口，也不要把本机地址发给远程团队当作上线地址。

在工作空间根安装工具箱依赖并查看现有能力：

```sh
npm ci --prefix workflow-kit
node workflow-kit/bin/pwf.mjs help
```

这一步会安装本机依赖；普通上下文检查不会自动替你执行它。无运行环境时仍可先阅读项目和本手册，准确报告缺项。

## 第一次进入：选项目并读取上下文

自然语言示例：

> 先读工作空间 AGENTS.md，列出业务项目。我想继续指定项目的原型设计，先检查当前证据和缺项，再说明本轮编辑范围。

在工作空间根执行：

```sh
node workflow-kit/bin/pwf.mjs project list --workspace . --include-examples
```

结果应包含 projectId、名称、配置路径、business/example/unspecified 分类及配置错误。用户指定项目优先；只有唯一且分类明确的业务项目时才可自动采用。多个或未分类候选、重复 ID 必须先消除歧义，不能默认选示例。

使用发现结果中的真实目录进入业务项目：

```sh
cd projects/PROJECT_DIR
node tooling/run.mjs project check --project project.config.yaml
```

若提示锁定工具尚未恢复，使用本项目的恢复入口：

```sh
node tooling/restore.mjs
npm ci --prefix .local/workflow-kit --omit=dev
```

恢复会创建本机缓存，安装会下载声明依赖；它们不修改需求正文或工具锁。工具入口若仍为旧版缺陷或工具锁不存在，先看 [版本恢复](#独立迁出与工具版本)，不要设置临时环境变量绕过校验。

工具就绪后在业务项目根执行：

```sh
node tooling/run.mjs workflow context --project project.config.yaml --intent resume
node tooling/run.mjs workflow next --project project.config.yaml --intent resume
```

读取 `projectId/changeId`、`stateRevision`、`recordedStage`、`evidenceStatus`、`checkpoint`、`readFiles`、`missingInputs`、`pendingDecisions` 和建议动作。`valid` 表示对应证据通过本地核验；`missing`、`conflict` 和 `not-probed` 分别表示缺失、冲突及未探测。已有阶段名称不是当前服务可访问或远端仍成功的证明。

成功判断：能找到正确项目、规则源、有效产物和下一动作，且检查没有创建项目、启动服务或访问远端。下一步选择下面对应场景。没有保存过交接时，应明确目标缺项，不能编造前一次会话的任务。

如果用户要修改框架入口、工具或共享协议，目标是工作空间根 OpenSpec 与工具箱，不是上面的业务 context。读取根 AGENTS、工具箱 AGENTS 及明确变更的 proposal/design/specs/tasks；多个变更无法判断时先明确范围。不能为框架维护新建业务配置、默认进入示例或推进某业务项目阶段。

## 新建空白业务项目

自然语言示例：

> 新建一个空白产品设计项目，名称为……，不要预填客户管理等业务规则。先建立可检查入口，再一起分析需求。

输入：未占用的目标目录、稳定 projectId 和名称。在工作空间根执行：

```sh
node workflow-kit/bin/pwf.mjs project init --directory projects/my-product --id my-product --name 我的产品 --template blank
```

默认也是 blank。只有明确体验客户示例时才用 `--template customer-demo`，它生成 example 分类，不能当作真实项目的默认需求。

新建流程生成配置、最小 Vite 原型、空需求、分析模板、项目规则、工具锁与恢复入口，并材料化锁定工具。它不意味着需求已分析或页面已设计。进入新项目后安装工具运行依赖：

```sh
cd projects/my-product
npm ci --prefix .local/workflow-kit --omit=dev
```

业务原型依赖单独安装：若 `prototype/package-lock.json` 已存在，执行 `npm ci --prefix prototype`；首次没有锁文件时执行 `npm install --prefix prototype` 创建锁，此后使用 npm ci。

成功判断：`project check` 通过，projectType 为 business、需求为空、初始阶段未完成，未出现示例业务规则；原目录和其他项目没有被覆盖。下一步进入需求分析。

## 把已有原型接入为新项目

自然语言示例：

> 将我指定的已有原型接入工作流，保留源目录、需求和历史包。先按明确映射给出预演，不猜工作台里哪一个是目标。

输入：源根目录、新目标目录、新 projectId，以及映射 JSON。源路径以 `--source` 为根；`prototype.config/output` 相对 `prototype.source`。以下是需按真实文件替换的最小 Vite 示例：

```json
{
  "schemaVersion": 1,
  "prototype": {
    "source": "prototype",
    "adapter": "vite",
    "config": "vite.config.mjs",
    "output": "dist"
  },
  "pages": [{"id": "home", "name": "首页", "path": "./index.html"}],
  "requirements": "data/requirements/source-project.json",
  "supportingFiles": [],
  "legacyReviews": []
}
```

静态原型使用 `adapter: "static"`，不填 config，output 可省略或为 `"."`。支持资料映射的 target 必须在新项目 `inputs/` 内；旧评审映射 target 为历史标识，落入 `inputs/legacy-reviews/`。不要映射源 `.local/`、凭据、node_modules 或整个工作台运行时。

在工作空间根执行：

```sh
node workflow-kit/bin/pwf.mjs project import --source SOURCE_DIR --directory projects/new-product --id new-product --mapping MAPPING_FILE.json --dry-run
```

核对复制文件、必要适配和缺项。预演不创建目标，也不修改源。确认映射属于用户要求的范围后，去掉 `--dry-run` 执行同一命令。空白目录和ID冲突必须先处理，不能通过清空用户目录绕过。

成功判断：新项目使用独立身份，reqId、模块、绑定和扩展规则保持完整；有原始需求备份与来源摘要。旧评审保留原字节和原身份，不能自动批准新项目。依赖安装、Inspector/来源和运行效果尚需随后检查，不能把“复制完成”当作原型可运行。下一步读取新项目上下文并验证原型。

“复制成新项目”不同于“原项目迁到另一目录”：后者保留自身 projectId、锁与历史，见迁出章节。

更多支持资料和历史包映射例子见 [导入映射说明](import-mapping.md)。

## 阶段 1：需求分析

自然语言示例：

> 分析这个模块的目标、角色、流程、字段、统计和异常，列出尚需我决定的事项，将已确认规则落实到本项目需求源。

输入：项目来源材料及业务决定。先读 `analysis/`、需求 JSON 和当前业务变更；有 prd-writer 时可按其文件增强分析，没有原生注册时直接依据 [阶段说明](workflow.md) 完成基础分析。用户明确点名但缺失的 Skill 要如实处理。

把目标、流程、范围取舍和未决问题保存在分析/OpenSpec 中，详细规则只编辑 `data/requirements/<projectId>.json`。规则包含场景、交互、权限、异常和验收条件；字段表注明类型、默认值、必填、校验，统计注明口径、范围、刷新时机。结构定义见 [需求 schema](../schemas/requirements.schema.json)。不能把尚未确认的建议写成业务事实。

在业务项目根执行：

```sh
node tooling/run.mjs requirements validate --project project.config.yaml
node tooling/run.mjs requirements project --project project.config.yaml --change CHANGE_ID
```

第二条会生成业务 OpenSpec 变更内的受控规格，不是只读命令。缺少业务场景时先补 JSON，投影器不会编造场景。遇到手改冲突时保留文件，把有效决定吸收回唯一需求源后再受控重生成。

成功判断：规则可校验、模块关系和元素关联明确；投影来源可追溯；关键未决问题有明确记录。下一步进入原型；验收条件现在就维护，产品验收执行仍独立预留。

## 阶段 2：原型与需求编辑

自然语言示例：

> 按这些已确认需求修改 HTML 原型，保持已有技术栈，接入独立需求空间，并验证保存恢复和编辑拦截。

输入：已确认需求、页面清单、现有设计和原型源。Agent 读取 [原型设计能力](../.agents/skills/html-product-design/SKILL.md) 与 [Studio 接入](studio.md)。在业务脚本前加载 Inspector，登记精确 origin，并补稳定 `data-req-id/data-req-element`；不会自动修改外部工作台上游。

原型依赖就绪后，在业务项目根启动：

```sh
node tooling/run.mjs studio dev --project project.config.yaml
```

打开实际返回的统一入口：默认完整设计；点击“功能需求”进入模块说明。点击元素定位所属子模块，需要时再编辑；字段集中在子模块字段表，不能逐字段新建导航模块。点击保存后检查真实 JSON 和 revision，刷新再选同一功能验证恢复。

验证预览模式的查询、弹窗和模拟提交；切到需求空间后验证删除、提交以及 Enter/Space 不执行模拟业务。切换空间应保留同一个 iframe、弹窗与输入。详尽规则以工作流和 Studio 说明为准。

成功判断：上述交互有实际检查结果，需求在 JSON 持久化，预览与需求模式均正确。下一步生成预览包；本机入口可供本机使用，远程团队需要后续站点部署。

## 阶段 3：预览、静态包与项目 Pages

自然语言示例：

> 为这个项目生成原型与需求统一评审包，先验证本地静态效果；目标仓库未提供时列缺项，不替我选仓库。

在业务项目根：

```sh
node tooling/run.mjs review preview --project project.config.yaml
node tooling/run.mjs review export --project project.config.yaml --output _site
```

预览允许未提交来源，产物在项目 `.local/`，导出站点在 `_site/`。完整包包含原型、需求、Studio UI 和资源，使用静态 HTTP 服务检查；不要双击 file://。停掉开发服务后，统一入口、页面资源和需求空间仍应工作。

需要团队站点时，由本项目 `github` 配置指定 owner、repository、branch、basePath 和实际站点 URL；仓库子路径资源也要验证。GitHub Pages 来源、权限和提交范围见 [发布说明](publication.md)。不能把业务端口与工作台端口当成两个交付地址。

首次配置 CI、冻结和提交步骤见下一节。CI 无本机 preview 缓存时必须能够从项目正式归档组装站点；不要只上传临时缓存或依赖过期的 Actions artifact。

成功判断：本地完整静态包通过；只有取得实际部署 URL 并回读目标 manifest 与关键资源后才报告在线。下一步开展评审并冻结正式版本。

## 阶段 4：评审修改、冻结与批准

自然语言示例：

> 整理这次评审意见，修改对应需求与原型。阻塞意见关闭后冻结共同版本，记录我明确提供的评审决定。

意见与处置保存在项目 `reviews/` 或分析记录中，规则修改回到 JSON，页面修改回到原型。先保存并校验正式交接完整性：

```sh
node tooling/run.mjs requirements validate --project project.config.yaml --formal
```

正式冻结要求本业务项目独立 Git 仓库中的原型、需求和配置已提交。若尚无仓库，先在**业务项目根**完成 Git 初始化与明确文件提交；不要在工作空间根执行 Git 初始化，不把 `.local/` 或凭据纳入提交。源码提交后执行：

```sh
node tooling/run.mjs review freeze --project project.config.yaml --change CHANGE_ID
```

得到正式 REVIEW_ID 与 manifest。归档位于 `site-archive/review/<reviewId>/`；构建中来源变化会失败，同一版本重试复用身份。批准只记录实际决定：

```sh
node tooling/run.mjs review approve --project project.config.yaml --review REVIEW_ID --actor ACTUAL_REVIEWER --decision approved
```

记录拒绝时使用 `--decision rejected`。批准记录独立引用 manifest，旧快照字节不变；Agent 不代替评审者确认。新修改需要新草稿和新快照。

若要配置该项目的 CI，在确认目标后执行 `pages configure`；已有文件不会静默覆盖。将新归档、评审记录、状态、工具锁与归档、恢复脚本及 CI 配置提交到本项目仓库。只有明确升级工具时才执行工具箱 bundle，日常发布不要无意替换项目锁。

```sh
node tooling/run.mjs pages configure --project project.config.yaml
node tooling/run.mjs pages publish --project project.config.yaml --review REVIEW_ID
```

没有 `--execute` 的 publish 只准备本地产物；缺目标准确返回待配置。需要实际发布且已有对应授权时，执行同一 publish 命令并加 `--execute`；Actions 请求返回 pending 仍不代表上线。拿到实际部署 URL 后：

```sh
node tooling/run.mjs pages verify --project project.config.yaml --review REVIEW_ID --url ACTUAL_DEPLOYMENT_URL
```

成功判断：正式来源、静态包和批准分别有证据；上线验证必须匹配 reviewId、manifest hash 与资源，旧版本链接仍可访问。业务交接使用固定 `review/<reviewId>/` 地址，不使用不断变化的“最新预览”。

## 阶段 5：禅道预演与正式交接

自然语言示例：

> 把批准的版本拆成禅道故事和建议任务，附验收条件与固定评审链接；先给我可核对交接包，再按明确目标和已有授权执行。

输入：批准 REVIEW_ID、可达固定评审地址、实例与产品/项目/执行/接收人。产品负责业务拆分，研发负责技术拆分与估时，项目经理组织执行。MCP 端点与网站地址分别配置，不能从网站路径猜工具入口。

需要连接检查时，在业务项目根显式执行：

```sh
node tooling/run.mjs zentao mcp-discover --project project.config.yaml
node tooling/run.mjs zentao mcp-status --project project.config.yaml
```

这两项会访问明确配置的 MCP 服务；普通 context 不会自动调用。发现工具成功不等于所有写动作可用。按真实 tools/list 登记名称、参数、回读和可靠查询能力；服务允许范围也需匹配。认证使用本机隐藏输入或安全环境引用，详见 [禅道说明](zentao.md)，不在聊天、参数、项目正文或静态包中保存密码/token。

没有批准版本时只能生成草案：

```sh
node tooling/run.mjs zentao plan --project project.config.yaml --draft
```

有批准版本时生成正式计划，再按输出的计划路径预演：

```sh
node tooling/run.mjs zentao plan --project project.config.yaml --review REVIEW_ID
node tooling/run.mjs zentao sync --project project.config.yaml --plan delivery/zentao/plans/PLAN_ID.json
```

生成计划不等于已发送，默认 sync 不写远端。正式同步在目标、映射和已有授权明确后增加 `--execute`。逐条结果成功回读后保存映射；结果未知时先运行 `zentao reconcile --project project.config.yaml --plan delivery/zentao/plans/PLAN_ID.json`，无可靠核对能力则保留待核对，不盲目重建。

同步、实际指派与接收分别记录。项目经理实际确认接收后，使用明确证据登记：

```sh
node tooling/run.mjs collaboration receipt --project project.config.yaml --review REVIEW_ID --actor ACTUAL_RECEIVER --evidence RECEIPT_REFERENCE
```

成功判断：实际远端 ID、产品字段回读、固定基线和接收证据一致。模拟结果只证明本地契约，不能用于真实接收或阶段完成。下一步进入研发协同。

## 阶段 6：研发澄清、变更与提验

自然语言示例：

> 记录研发澄清及实现证据；若规则改变，先分析影响并记录产品和项目经理决定，不覆盖进行中的技术任务。

记录有明确基线的澄清：

```sh
node tooling/run.mjs collaboration record --project project.config.yaml --review REVIEW_ID --actor ACTUAL_AUTHOR --type clarification --content CLARIFICATION_TEXT
```

已交接需求修改后，比较旧批准版本和新草稿：

```sh
node tooling/run.mjs changes impact --project project.config.yaml --review OLD_REVIEW_ID
```

影响清单按 reqId 列出新增、修改、移除和明确依赖。产品范围决定与项目经理影响确认分别来自实际记录，在 decisions JSON 中提供 actor、decision 和 evidence，再提交：

```sh
node tooling/run.mjs changes confirm --project project.config.yaml --impact IMPACT_ID --decisions DECISIONS_FILE.json
```

批准新基线后重新生成计划；正式同步时传 `--impact IMPACT_ID`。移除仅产生取消/替代建议和待处置项，不自动删除任务；A 改动不更新无依赖的 B。

已明确实现版本与验证证据后登记：

```sh
node tooling/run.mjs collaboration implementation --project project.config.yaml --review REVIEW_ID --version IMPLEMENTATION_VERSION --evidence VALIDATION_REFERENCE --actor ACTUAL_AUTHOR
```

只记录所给证据。任务关闭或产品批准不能自动生成实现结论；历史实现补录不回退当前实现基线。产品验收状态独立保留，当前不提供完整验收工作台。

## 换对话或 Agent：保存并恢复任务

自然语言示例：

> 为当前任务保存接手信息，记录目标、实际产物和未决问题。下一次会话只需项目目录即可继续；不复制需求正文或整段聊天。

先读取当前上下文与 stateRevision：

```sh
node tooling/run.mjs workflow context --project project.config.yaml --intent resume
```

将以下语义输入保存为本项目 `.local/handoff.input.json`，根据实际工作修改。引用路径相对项目根；没有完成的项目保留空数组，不编造证据。下面的分析文件必须真实存在，不能把示例当作完成事实。

```json
{
  "goal": "继续完善当前模块的原型与需求说明",
  "completedWork": ["analysis/analysis.md"],
  "confirmedDecisions": [],
  "pendingQuestions": ["仍待业务负责人确认的具体问题"],
  "nextActions": [{"id": "prototype.edit", "description": "按已确认范围继续原型设计"}],
  "writeScope": ["prototype/**", "data/requirements/PROJECT_ID.json"]
}
```

把 N 替换成刚读出的 stateRevision，不使用需求 JSON 的 revision：

```sh
node tooling/run.mjs workflow checkpoint --project project.config.yaml --file .local/handoff.input.json --expected-state-revision N
```

工具追加 `.workflow/checkpoints/<id>.json` 并提交状态指针；自动记录 observed 与 committed 修订、来源、工具身份和父记录。交接自身提交会使修订自增，不会因此立即过期。冲突时先重读并核对自己的语义输入，不用旧状态强行覆盖。

新会话可用普通提示：

> 读取本项目 AGENTS.md，使用锁定工具读取 workflow context；核对交接是否仍有效，说明当前目标、证据、缺项和编辑范围，然后继续我指定的动作。

也可导出只读 Markdown 视图：

```sh
node tooling/run.mjs workflow context --project project.config.yaml --format markdown
```

成功判断：另一位没有历史聊天、没有原生 Skills 的接手者能找回相同目标和证据；来源改变时能识别陈旧交接并重新评估。阶段、建议和交接文字不会变成新的外部操作授权。

## 独立迁出与工具版本

迁出保留项目身份。携带 `AGENTS.md/README`、配置、分析、需求、原型、业务 OpenSpec、正式归档与评审记录、`.workflow/`、交接/协同目录，以及 `tooling/toolchain.json`、固定工具归档和管理型 run/restore 入口。`.local/`、node_modules、凭据及浏览器会话重新配置，不作为可移植来源。

在迁出项目根执行：

```sh
node tooling/restore.mjs
npm ci --prefix .local/workflow-kit --omit=dev
node tooling/run.mjs project check --project project.config.yaml
```

0.2 项目再运行 `workflow context`。协议、手册和能力文件来自核验的 `.local/workflow-kit/`，无需原工作空间或全局 Skills。业务原型依赖仍按其锁单独安装。本机 preview 丢失应重建，不能把保留指针当作原服务已经恢复；正式历史包不需要重写。

### 旧 0.1 的兼容引导器修复

旧 run/restore 存在路径不一致，不能承诺其未修复入口本来就能独立恢复。在仍可使用工作空间工具箱时，显式执行：

```sh
node workflow-kit/bin/pwf.mjs toolkit bootstrap --project projects/PROJECT_DIR/project.config.yaml
```

它只更新经识别的管理型 run/restore，并在 `tooling/bootstrap-history/` 留备份/变更记录；不改变 toolchain.json、0.1 归档或包内容，也不自动恢复或安装依赖。随后按迁出步骤恢复，仍运行锁定的 0.1；该版本不支持 context 等 0.2 能力。自定义引导器冲突要保留并明确处理。

### 显式升级到 0.2

用户决定采用新版能力后，先备份项目入口、配置、锁和状态。用已核验的新工具箱执行 bundle（工作空间根）：

```sh
node workflow-kit/bin/pwf.mjs toolkit bundle --project projects/PROJECT_DIR/project.config.yaml
```

bundle 明确更新项目锁，保留旧归档和锁历史，并安装兼容引导器；再恢复、安装新运行依赖、核对版本与状态。它不同于 bootstrap，不能作为每次接手或普通发布的隐式步骤。不要用未核验父目录工具或 `PWF_KIT_ROOT` 绕过锁；同版本源码被修改也应拒绝加载。

升级只改变框架入口、工具和兼容元数据，不覆盖业务需求、原型、历史包或本机凭据。回退根据备份恢复旧锁与匹配工具；不要用回退覆盖后来有效的业务数据或自动撤销已发生的外部操作。

## 常见故障

| 现象 | 识别与处理 | 保留边界 |
| --- | --- | --- |
| 项目歧义或重复 ID | 重新运行发现，采用用户明确配置路径，处理身份冲突 | 不重新初始化或默认进入示例 |
| 旧工具没有 context/next | 查看锁与 help；按需要先修复引导器，再明确升级 | 不把运行新版伪装为旧锁 |
| 工具归档或材料化内容不匹配 | 停止加载；核对锁、归档来源和备份，再显式恢复 | 不相信缓存 stamp，不下载猜测替代版本 |
| 缺依赖 | 工具与 prototype 分别按锁安装；无锁的原型首次建立锁 | 不将缺依赖描述为业务规则错误 |
| 端口冲突或服务已停止 | 查看本机配置与进程，登记空闲端口后重启；以实际输出为准 | 不宣称自动迁移，也不依赖旧地址 |
| 本机预览缺失 | context 显示 missing；从当前来源重建 preview | 保留正式归档，不重写旧批准 |
| 快照或批准摘要冲突 | 停止依赖动作，核对版本与源文件 | 不自动重批或修补不可变快照 |
| 交接过期 | 重读 context，核对来源和 pendingDecisions 后保存新交接 | 保留历史，不机械执行旧 nextActions |
| expected revision 冲突 | 重读最新状态，重新评估本次更新再提交 | 不把旧整份状态覆盖回去 |
| 残留或未知锁 | 按协作协议核对所有者；仅已证实退出的本机持有者可显式恢复 | 不按超时抢占未知主机/进程 |
| MCP 认证失效 | 用本机认证入口更新令牌，再明确执行发现/只读验证 | 不读取浏览器 cookie、不把密码交给聊天 |
| 禅道写入结果未知 | 先 reconcile；无法可靠核对则保留待处理 | 不盲目重建或删除历史条目 |
| 没有仓库或禅道业务目标 | 继续本地包、预演和缺项记录 | 不声称真实部署、同步、接收或验收 |

## 如何核对这份手册

使用临时项目演练：从根发现项目、空白新建或明确导入、进入上下文、启动预览、保存需求并刷新恢复、保存交接、由另一位无历史接手者恢复。再将项目移到没有原工作空间和全局 Skills 的目录，恢复锁定工具重复检查。

实际记录命令、产物、缺项和未测范围；远端目标不存在时只验证本地前置条件或模拟契约。不要把同模型的多个 Agent 演练宣称为所有模型/客户端已测试。已完成范围见 [验证记录](verification.md)。
