/** Exchange a password interactively for an API token. Passwords never reach disk or argv. */
import {mkdir,lstat,chmod,open,rename,rm,realpath} from 'node:fs/promises';
import {realpathSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {promptCredentials} from './terminal-credentials.mjs';

function siteOrigin(value){
 let url;try{url=new URL(value)}catch{throw Error('站点地址无效，请使用明确的 HTTP(S) 站点 origin。')}
 if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname))throw Error('站点地址必须是 HTTP(S) origin，不包含凭据、API 路径或查询。');
 return url.origin;
}
function validToken(value){return typeof value==='string'&&value.length>0&&value.length<=16384&&!/[\s\u0000-\u001f\u007f]/u.test(value)}
function loginError(code,message){return Object.assign(new Error(`禅道登录失败 [${code}]：${message}`),{code})}
// Rebuild only verified upstream messages. An arbitrary plugin error may contain credentials.
function safeServerReason(payload,secrets){
 const reasons=[payload?.reason,payload?.message].filter(value=>typeof value==='string'&&value.length<=1024);
 for(const value of reasons){
  if(secrets.some(secret=>typeof secret==='string'&&secret.length>0&&value.includes(secret)))continue;
  if(value==='登录失败，请检查您的用户名或密码是否填写正确。')return '服务端提示“登录失败，请检查您的用户名或密码是否填写正确。”这是一条通用认证拒绝提示，不能据此确认密码有误。';
  const locked=/^密码尝试次数太多，请联系管理员解锁，或([0-9]{1,6})分钟后重试。$/u.exec(value);
  if(locked)return `服务端提示账号已锁定，请联系管理员解锁，或 ${locked[1]} 分钟后重试。`;
 }
 return '服务端拒绝登录；返回的原因未匹配已核对的安全文案，原文未输出。请核对禅道服务端登录日志。';
}
async function secureProfile(value){
 if(typeof value!=='string'||!value.trim())throw Error('必须明确提供本机凭据 profile 目录。');
 const directory=resolve(value);await mkdir(directory,{recursive:true,mode:0o700});
 const info=await lstat(directory);if(!info.isDirectory()||info.isSymbolicLink())throw Error('凭据 profile 必须是实际目录，不能使用符号链接。');
 await chmod(directory,0o700);
 try{const file=await lstat(join(directory,'credentials.json'));if(!file.isFile()||file.isSymbolicLink())throw Error('凭据文件不能使用符号链接或特殊文件。')}catch(error){if(error.code!=='ENOENT')throw error}
 return realpath(directory);
}

/** Library entry point for explicit callers. Returns only a non-sensitive status summary. */
export async function loginAndStore({site,profile,account,password,fetchImpl=globalThis.fetch}={}){
 const origin=siteOrigin(site);
 if(typeof account!=='string'||!account.trim()||account.length>256||typeof password!=='string'||!password.length||password.length>4096)throw Error('账号和密码均需在本机终端中输入。');
 let directory;try{directory=await secureProfile(profile)}catch{throw Error('本机凭据目录不可安全写入，请检查 profile 路径和权限。')}
 const endpoint=new URL('/api.php/v2/users/login',origin);
 let response;
 try{response=await fetchImpl(endpoint.href,{method:'POST',redirect:'error',signal:AbortSignal.timeout(15000),headers:{Accept:'application/json','Content-Type':'application/json'},body:JSON.stringify({account:account.trim(),password})})}
 catch{throw loginError('ZENTAO_CONNECTION','指定 API 无法连接或拒绝重定向；没有尝试其他端点。')}
 if(response.redirected)throw Error('禅道登录失败：登录 API 不允许重定向。');
 if(response.url){let actual;try{actual=new URL(response.url)}catch{throw Error('禅道登录失败：响应来源无法核对。')}if(actual.origin!==origin||actual.pathname!==endpoint.pathname)throw Error('禅道登录失败：响应来源与指定 API 不一致。')}
 const httpStatus=Number.isInteger(response.status)?String(response.status):'未知';
 let payload;try{payload=await response.json()}catch{throw loginError('ZENTAO_RESPONSE_FORMAT',`API 返回 HTTP ${httpStatus}，但响应不是有效 JSON；可能是访问限制或服务端错误，请核对服务端日志。`)}
 if(!payload||typeof payload!=='object'||Array.isArray(payload))throw loginError('ZENTAO_RESPONSE_FORMAT',`API 返回 HTTP ${httpStatus}，但 JSON 结构与登录契约不符。`);
 const token=payload?.token??payload?.data?.token;
 if(payload.error||['fail','failed','error'].includes(payload.status))throw loginError('ZENTAO_LOGIN_REJECTED',`HTTP ${httpStatus}；${safeServerReason(payload,[account,account.trim(),password,payload.token,payload.data?.token])}`);
 if(!response.ok)throw loginError('ZENTAO_HTTP',`API 返回 HTTP ${httpStatus}；未获得成功登录响应，请核对实例访问限制和服务端日志。`);
 if(payload.status!=='success')throw loginError('ZENTAO_RESPONSE_STATUS','API 未返回明确的 success 状态；未保存令牌。');
 if(token===undefined||token===null||token==='')throw loginError('ZENTAO_TOKEN_MISSING','API 声明登录成功，但没有返回令牌；请核对实例 API 配置。');
 if(!validToken(token))throw loginError('ZENTAO_TOKEN_INVALID','API 返回的令牌格式无效；未保存令牌。');
 const createdAt=new Date().toISOString(),credentialFile=join(directory,'credentials.json'),temporary=join(directory,'.credentials-'+randomUUID()+'.tmp');
 let handle;
 try{
  handle=await open(temporary,'wx',0o600);
  await handle.writeFile(JSON.stringify({schemaVersion:1,site:origin,token,createdAt},null,2)+'\n');await handle.sync();await handle.close();handle=null;
  await rename(temporary,credentialFile);await chmod(credentialFile,0o600);
 }catch{if(handle)await handle.close().catch(()=>{});await rm(temporary,{force:true}).catch(()=>{});throw Error('禅道登录已响应，但本机令牌保存失败；未输出任何凭据。')}
 return {ok:true,site:origin,profile:directory,createdAt};
}

function parseArgs(args){const options={};for(let i=0;i<args.length;i++){const arg=args[i];if(arg==='--help')return {help:true};if(!['--site','--profile'].includes(arg)||!args[i+1]||args[i+1].startsWith('--'))throw Error('只接受 --site 和 --profile；账号密码必须在本机终端交互输入。');options[arg.slice(2)]=args[++i]}if(!options.site||!options.profile)throw Error('需要 --site <站点origin> --profile <本机凭据目录>。');return options}
export async function main(args=process.argv.slice(2)){
 try{const options=parseArgs(args);if(options.help){process.stdout.write('用法：node zentao-auth.mjs --site <HTTP(S)站点origin> --profile <本机凭据目录>\n请在真实终端中输入账号和隐藏密码。\n');return 0}siteOrigin(options.site);const credentials=await promptCredentials();await loginAndStore({...options,...credentials});process.stdout.write('登录成功，API 令牌已安全保存到指定本机 profile；未保存账号或密码。\n');return 0}
 catch(error){process.stderr.write((error?.message||'登录失败，未输出任何凭据。')+'\n');return 1}
}
function isMain(){try{return !!process.argv[1]&&realpathSync(process.argv[1])===fileURLToPath(import.meta.url)}catch{return false}}
if(isMain())process.exitCode=await main();
