/** Codex http_headers_helper entry point. Its stdout is private protocol output, not status text. */
import {readFile,lstat} from 'node:fs/promises';
import {realpathSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

function originOf(value){let url;try{url=new URL(value)}catch{throw Error('本机禅道凭据或连接配置中的站点无效。')}if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.hash||url.search)throw Error('本机禅道连接站点必须是无凭据的 HTTP(S) 地址。');return url.origin}
function validToken(value){return typeof value==='string'&&value.length>0&&value.length<=16384&&!/[\s\u0000-\u001f\u007f]/u.test(value)}
async function readLocal(file,{secret=false}={}){
 try{const info=await lstat(file);if(!info.isFile()||info.isSymbolicLink())throw Error('本机凭据和连接配置不能使用符号链接或特殊文件。');if(secret&&(info.mode&0o077))throw Error('凭据文件权限过宽，请重新通过本机交互登录保存。');return JSON.parse(await readFile(file,'utf8'))}catch(error){if(error.code==='ENOENT')return null;if(error instanceof SyntaxError)throw Error('本机凭据或连接配置不是有效 JSON。');throw error}
}

/** The caller must keep the returned header out of normal logs and status displays. */
export async function readAuthHeaders({profile,env=process.env}={}){
 if(typeof profile!=='string'||!profile.trim())throw Error('Header helper 需要明确的 --profile 目录。');
 const directory=resolve(profile);
 try{const info=await lstat(directory);if(!info.isDirectory()||info.isSymbolicLink())throw Error('Header helper profile 必须是实际目录。')}catch(error){if(error.code==='ENOENT'){if(validToken(env.ZENTAO_TOKEN))return {Token:env.ZENTAO_TOKEN};return {}}throw error}
 const [credentials,connection]=await Promise.all([readLocal(join(directory,'credentials.json'),{secret:true}),readLocal(join(directory,'connection.json'))]);
 if(credentials&&(!credentials.site||!validToken(credentials.token)))throw Error('本机凭据不完整，请重新登录。');
 if(credentials){const stored=originOf(credentials.site);if(connection?.baseUrl&&stored!==originOf(connection.baseUrl))throw Error('本机令牌站点与该 profile 的连接站点不匹配，拒绝发送令牌。')}
 else if(connection?.baseUrl)originOf(connection.baseUrl);
 const token=env.ZENTAO_TOKEN||credentials?.token;
 if(!token)return {};if(!validToken(token))throw Error('令牌格式无效，拒绝生成请求头。');
 return {Token:token};
}
function parseArgs(args){if(args.length!==2||args[0]!=='--profile'||!args[1]||args[1].startsWith('--'))throw Error('Header helper 只接受 --profile <本机凭据目录>。');return {profile:args[1]}}
export async function main(args=process.argv.slice(2)){
 try{const headers=await readAuthHeaders(parseArgs(args));process.stdout.write(JSON.stringify(headers)+'\n');return 0}
 catch{process.stdout.write('{}\n');process.stderr.write('禅道请求头未生成：请检查本机凭据、站点绑定和文件权限。\n');return 1}
}
function isMain(){try{return !!process.argv[1]&&realpathSync(process.argv[1])===fileURLToPath(import.meta.url)}catch{return false}}
if(isMain())process.exitCode=await main();
