#!/usr/bin/env node
/** Workspace-local launcher for the unmodified official ZenTao MCP release. */
import {readFile,writeFile,open,mkdir,realpath} from 'node:fs/promises';
import {join,resolve,relative,isAbsolute,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawn,execFile} from 'node:child_process';
import {promisify} from 'node:util';
import YAML from 'yaml';
const exec=promisify(execFile),script=fileURLToPath(import.meta.url),defaultDirectory=fileURLToPath(new URL('../../.local/zentao-mcp/',import.meta.url));
const args=process.argv.slice(2),positional=[];let directory=defaultDirectory;
for(let i=0;i<args.length;i++){if(args[i]==='--profile'){if(!args[i+1]||args[i+1].startsWith('--'))throw Error('--profile 需要本机profile根目录');directory=resolve(args[++i])}else if(args[i].startsWith('--profile=')){directory=resolve(args[i].slice('--profile='.length))}else positional.push(args[i])}
const pidFile=join(directory,'process.json'),logFile=join(directory,'server.log');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function json(file){return JSON.parse(await readFile(file,'utf8'))}
async function save(file,value){await writeFile(file,JSON.stringify(value,null,2)+'\n',{mode:0o600})}
async function localPath(value){
 if(typeof value!=='string'||!value||isAbsolute(value))throw Error('source-profile.paths 必须使用profile根内相对路径');
 const root=await realpath(directory),file=await realpath(resolve(root,value)),rel=relative(root,file);
 if(isAbsolute(rel)||rel==='..'||rel.startsWith('..'+sep))throw Error('source-profile路径越出profile根目录');return file;
}
async function context(){
 const profile=await json(join(directory,'source-profile.json'));
 if(profile.schemaVersion!==1)throw Error('不支持的source-profile版本');
 const source=await json(await localPath(profile.paths?.manifest)),configFile=await localPath(profile.paths?.config),config=YAML.parse(await readFile(configFile,'utf8'));
 const binary=await localPath(profile.paths?.binary),schemaFile=await localPath(profile.paths?.schema),sandboxPolicy=await localPath(profile.paths?.sandboxPolicy),workingDirectory=await localPath(profile.paths?.workingDirectory);
 const platform=profile.platform||Object.fromEntries(['os','arch'].map((key,i)=>[key,source.platform?.split('-')[i]]));
 if(process.platform!==platform.os||process.arch!==platform.arch)throw Error(`官方包平台不匹配：需要 ${platform.os}/${platform.arch}，当前 ${process.platform}/${process.arch}`);
 if(sha(await readFile(binary))!==source.binarySha256)throw Error('官方MCP二进制校验失败');
 if(sha(await readFile(schemaFile))!==source.schemaSha256)throw Error('官方MCP schema校验失败');
 if(!source.loopbackPolicySha256||sha(await readFile(sandboxPolicy))!==source.loopbackPolicySha256)throw Error('MCP本机绑定策略校验失败');
 const endpoint=new URL(profile.deployment?.mcpUrl),host=endpoint.hostname.replace(/^\[|\]$/g,''),port=Number(endpoint.port);
 if(endpoint.protocol!=='http:'||!['127.0.0.1','::1'].includes(host)||!Number.isInteger(port)||port<1024||port>65535||endpoint.username||endpoint.password||endpoint.search||endpoint.hash)throw Error('source-profile的MCP地址必须是显式登记的loopback HTTP地址');
 const name=profile.serverName;if(typeof name!=='string'||!/^[a-z][a-z0-9-]*$/.test(name)||endpoint.pathname!==`/${name}/mcp`)throw Error('MCP路径与登记服务名不符');
 const listen=host.includes(':')?`[${host}]:${port}`:`${host}:${port}`;
 if(config.port!==listen||profile.deployment?.listen!==listen)throw Error('配置、MCP URL和登记监听地址不一致');
 if(config.servers?.length!==1||config.servers[0].name!==name)throw Error('当前bootstrap只接受已登记的单个服务');
 const registered=new URL(profile.deployment.apiBaseUrl);if(!['http:','https:'].includes(registered.protocol)||registered.username||registered.password||registered.search||registered.hash)throw Error('登记的上游API地址无效');
 const server=config.servers[0];if(new URL(server.base_url).href!==registered.href)throw Error('禅道目标与source-profile登记实例不符');
 if(!Array.isArray(profile.allowedApiMethods)||profile.allowedApiMethods.length!==1||profile.allowedApiMethods[0]!=='GET'||!Array.isArray(server.allow)||!server.allow.length||server.allow.some(rule=>!Array.isArray(rule.methods)||!rule.methods.length||rule.methods.some(method=>method!=='GET')))throw Error('当前bootstrap仅允许明确登记的GET工具');
 if(profile.launcher?.type!=='sandbox-exec'||typeof profile.launcher.executable!=='string')throw Error('需要登记可限制本机绑定的sandbox-exec启动器');
 return {source,profile,config,configFile,binary,schemaFile,sandboxPolicy,workingDirectory,listen,launcher:profile.launcher.executable,url:endpoint.href};
}
async function processStatus(){let record;try{record=await json(pidFile)}catch(e){if(e.code==='ENOENT')return {running:false};throw e}try{const actual=(await exec('ps',['-p',String(record.pid),'-o','command='])).stdout;const matchesProfile=record.profileRoot?resolve(record.profileRoot)===resolve(directory):resolve(directory)===resolve(defaultDirectory)&&!actual.includes('--profile');if(!matchesProfile||!actual.includes(script)||!actual.includes('--foreground'))return {...record,running:false,stale:true};return {...record,running:true}}catch{return {...record,running:false,stale:true}}}
async function checkBinding(pid,ctx){
 const lines=(await exec('lsof',['-nP','-a','-p',String(pid),'-iTCP','-sTCP:LISTEN'])).stdout.trim().split('\n').slice(1);
 if(!lines.length||lines.some(line=>!line.includes(`TCP ${ctx.listen} (LISTEN)`)))throw Error('官方进程存在未登记监听地址或MCP监听尚未就绪: '+lines.join(' | '));return lines;
}
async function foreground(){
 const ctx=await context();let child,closing=false;
 const close=async()=>{if(closing)return;closing=true;if(child&&!child.killed)child.kill('SIGTERM')};
 process.on('SIGTERM',()=>close().then(()=>process.exit(0)));process.on('SIGINT',()=>close().then(()=>process.exit(0)));
 try{
  // The registered process-local policy limits binding; upstream stays unchanged.
  child=spawn(ctx.launcher,['-f',ctx.sandboxPolicy,ctx.binary,'-config',ctx.configFile],{cwd:ctx.workingDirectory,stdio:['ignore','inherit','inherit']});
  child.once('error',error=>{console.error(error.message);close().then(()=>process.exit(1))});
  child.once('exit',(code,signal)=>{if(!closing){console.error(`official MCP exited ${code??signal}`);close().then(()=>process.exit(1))}});
  let binding,lastError;for(let i=0;i<30;i++){try{binding=await checkBinding(child.pid,ctx);break}catch(e){lastError=e;await new Promise(r=>setTimeout(r,100))}}
  if(!binding)throw lastError;
  await save(pidFile,{schemaVersion:1,profileRoot:directory,pid:process.pid,childPid:child.pid,url:ctx.url,mode:'readonly-schema-bootstrap',bindRestriction:ctx.profile.deployment.bindRestriction,bindings:binding,startedAt:new Date().toISOString()});
  console.log(JSON.stringify({running:true,url:ctx.url,pid:process.pid,childPid:child.pid,readonly:true}));
 }catch(e){await close();throw e}
}
async function start(){
 const ctx=await context(),existing=await processStatus();if(existing.running){await checkBinding(existing.childPid,ctx);return existing}
 await mkdir(directory,{recursive:true});const log=await open(logFile,'a',0o600);
 const daemon=spawn(process.execPath,[script,'--foreground','--profile',directory],{detached:true,stdio:['ignore',log.fd,log.fd],cwd:directory});daemon.unref();await log.close();
 for(let i=0;i<40;i++){const state=await processStatus();if(state.running&&state.pid===daemon.pid)return state;await new Promise(r=>setTimeout(r,100))}
 throw Error(`MCP启动失败；查看本地日志 ${logFile}`);
}
async function verify(){
 const ctx=await context(),state=await processStatus();if(!state.running)throw Error('本地MCP未启动');await checkBinding(state.childPid,ctx);
 const requests=[],responses=[];
 async function rpc(method,params,id){const message={jsonrpc:'2.0',method,...(id?{id}:{}),...(params?{params}:{})};requests.push(message);const res=await fetch(ctx.url,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json, text/event-stream'},body:JSON.stringify(message),signal:AbortSignal.timeout(10000)});const raw=await res.text();let body;try{body=raw?JSON.parse(raw):null}catch{body={unparsed:raw}}responses.push({method,status:res.status,body});if(!res.ok||body?.error){await save(join(directory,'protocol-verification.json'),{schemaVersion:1,status:res.status===401?'authentication-required':'failed',url:ctx.url,checkedAt:new Date().toISOString(),toolsListVerified:false,credentialsRead:false,upstreamApiCalled:false,requests,responses});throw Error(`${method}失败 HTTP ${res.status}: ${body?.error?.message||raw.slice(0,200)}`)}return body}
 const initialize=await rpc('initialize',{protocolVersion:'2025-03-26',capabilities:{},clientInfo:{name:'product-workflow-local-bootstrap',version:'0.1.0'}},1);
 await rpc('notifications/initialized');const list=await rpc('tools/list',{},2),tools=list?.result?.tools;if(!Array.isArray(tools))throw Error('tools/list没有返回工具数组');
 const schema=await json(ctx.schemaFile),getNames=new Set();
 for(const [path,item]of Object.entries(schema.paths||{}))if(item.get)getNames.add(item.get.operationId||'get_'+path.replace(/^\/+|\/+$/g,'').replaceAll('/','_').replace(/[{}:]/g,'').replace(/[^A-Za-z0-9_]+/g,'_').replace(/^_+|_+$/g,''));
 const unregistered=tools.map(t=>t.name).filter(name=>!getNames.has(name));if(unregistered.length)throw Error('MCP暴露非登记GET工具: '+unregistered.join(','));
 const record={schemaVersion:1,verifiedAt:new Date().toISOString(),url:ctx.url,protocolVersion:initialize.result?.protocolVersion,serverInfo:initialize.result?.serverInfo,toolCount:tools.length,toolNames:tools.map(t=>t.name),getOnly:true,credentialsRead:false,upstreamApiCalled:false,requests,responses};
 await save(join(directory,'protocol-verification.json'),record);return {verified:true,url:ctx.url,protocolVersion:record.protocolVersion,toolCount:tools.length,getOnly:true,credentialsRead:false,upstreamApiCalled:false};
}
try{if(positional.length>1)throw Error('只接受一个操作名');const action=positional[0]||'status';let value;if(action==='--foreground')await foreground();else if(action==='start')value=await start();else if(action==='status')value=await processStatus();else if(action==='verify')value=await verify();else if(action==='stop'){const status=await processStatus();if(status.running)process.kill(status.pid,'SIGTERM');value={stopping:status.running,pid:status.pid||null}}else throw Error('用法: zentao-server.mjs start|status|verify|stop [--profile 本机profile根目录]');if(value)console.log(JSON.stringify(value,null,2))}catch(e){console.error(JSON.stringify({error:e.message}));process.exitCode=1}
