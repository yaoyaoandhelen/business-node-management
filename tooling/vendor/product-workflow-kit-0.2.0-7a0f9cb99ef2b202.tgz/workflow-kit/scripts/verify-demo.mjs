import assert from 'node:assert/strict';
import {readFile,mkdir} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {chromium} from 'playwright';
import {kitRoot,loadProject,readJson,writeJson} from '../lib/core.mjs';
import {startStudio} from '../adapters/prototype-studio/index.mjs';

const config=process.argv.find(a=>a.startsWith('--project='))?.slice(10)||join(kitRoot,'../projects/workflow-demo/project.config.yaml');
const ctx=await loadProject(config),existing=process.argv.includes('--existing');let service,browser;
const checks=[],run=async(name,fn)=>{await fn();checks.push({name,passed:true});console.log('PASS '+name)};
try{
 if(!existing)service=await startStudio(ctx);
 browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(ctx.origins.studio+'/',{waitUntil:'networkidle'});const iframe=page.frameLocator('iframe');await iframe.locator('#create').waitFor();
 await run('完整页面默认展示',async()=>{assert.equal(await page.locator('iframe').count(),1);assert.equal(await page.locator('.module-sidebar').count(),0);await iframe.locator('h1').filter({hasText:'客户管理'}).waitFor()});
 await iframe.locator('#create').click();await iframe.locator('#customer-name').fill('状态保留检查');
 const frame=page.frames().find(f=>f.url().startsWith(ctx.origins.prototype));await frame.evaluate(()=>window.__workflowStateProbe='same-frame');
 await page.getByRole('button',{name:/功能需求/}).click();await page.locator('.module-sidebar').waitFor();await page.locator('.connection-shield').waitFor({state:'hidden'});
 await run('切换空间保留同一iframe与业务状态',async()=>{assert.equal(await frame.evaluate(()=>window.__workflowStateProbe),'same-frame');assert.equal(await iframe.locator('#customer-name').inputValue(),'状态保留检查');assert.equal(await iframe.locator('#customer-dialog').evaluate(d=>d.open),true)});
 await run('编辑模式阻止业务提交与键盘激活',async()=>{const before=await iframe.locator('#total').textContent();await iframe.locator('#customer-form button.primary').click();await iframe.locator('#customer-form button.primary').press('Enter');assert.equal(await iframe.locator('#total').textContent(),before);assert.equal(await iframe.locator('#customer-dialog').evaluate(d=>d.open),true)});
 await iframe.locator('#customer-name').click();await page.locator('[id="detail-customer.create"]').waitFor();await page.locator('[id="detail-customer.create"]').getByRole('button',{name:'编辑',exact:true}).click();await page.locator('.requirement-editor').waitFor();
 const input=page.locator('.requirement-editor .el-form-item').filter({has:page.locator('label').filter({hasText:'功能名称'})}).locator('input');const featureInput=(await input.count())?input.first():page.locator('.requirement-editor input').first();const original=await featureInput.inputValue();
 await featureInput.fill(original+' · 保存验证');await page.getByRole('button',{name:'保存修改',exact:true}).click();
 await run('需求编辑真实落盘',async()=>{await page.waitForTimeout(250);assert.equal((await readJson(ctx.paths.requirements)).requirements['customer.create'].featureName,original+' · 保存验证')});
 await page.reload({waitUntil:'networkidle'});await page.getByRole('button',{name:/功能需求/}).click();await page.locator('.connection-shield').waitFor({state:'hidden'});await page.getByRole('button',{name:/操作功能/}).click();
 await run('刷新恢复保存的需求',async()=>{await page.getByRole('heading',{name:original+' · 保存验证',exact:true}).waitFor()});
 await page.locator('[id="detail-customer.create"]').getByRole('button',{name:'编辑',exact:true}).click();await page.locator('.requirement-editor input').first().fill(original);await page.getByRole('button',{name:'保存修改',exact:true}).click();
 await page.getByRole('button',{name:'返回页面设计'}).click();await iframe.locator('#create').click();await iframe.locator('#customer-name').fill('预览新增验证');await iframe.locator('#contact').fill('测试联系人');await iframe.locator('#customer-form button.primary').click();
 await run('预览模式恢复业务交互',async()=>{await iframe.locator('#rows').getByText('预览新增验证',{exact:true}).waitFor();assert.equal(await iframe.locator('#customer-dialog').evaluate(d=>d.open),false)});
 await page.reload({waitUntil:'networkidle'});await iframe.locator('#create').waitFor();await mkdir(join(ctx.paths.local,'verification'),{recursive:true});await page.screenshot({path:join(ctx.paths.local,'verification/design.png'),fullPage:true});
 await page.getByRole('button',{name:/功能需求/}).click();await page.locator('.connection-shield').waitFor({state:'hidden'});await page.getByRole('button',{name:/数据统计/}).click();await page.screenshot({path:join(ctx.paths.local,'verification/requirements.png'),fullPage:true});
 await run('浏览器无脚本异常',async()=>assert.deepEqual(errors,[]));await writeJson(join(ctx.paths.local,'verification/dev-results.json'),{createdAt:new Date().toISOString(),projectId:ctx.projectId,checks});
}finally{if(browser)await browser.close();if(service)await service.close()}
