/** Minimal credential reader: no readline queue, history, shell expansion, or password echo. */
import {StringDecoder} from 'node:string_decoder';

const PASTE_START='\x1b[200~',PASTE_END='\x1b[201~';
function inputError(code,message){return Object.assign(new Error(message),{code})}

export async function promptCredentials({input=process.stdin,output=process.stdout}={}){
 if(input?.isTTY!==true||output?.isTTY!==true||typeof input.setRawMode!=='function')throw inputError('AUTH_TTY_REQUIRED','请在本机真实终端输入账号和隐藏密码；不接受参数或管道输入。');
 return new Promise((resolve,reject)=>{
  const decoder=new StringDecoder('utf8'),validator=new TextDecoder('utf-8',{fatal:true});
  const wasRaw=Boolean(input.isRaw),wasFlowing=input.readableFlowing===true;
  let stage='account',account=[],password=[],escape='',paste=false,pasted='',skipLF=false,complete=false,settled=false,commit;
  function write(value){output.write(value)}
  function cleanup(){
   if(commit)clearImmediate(commit);
   input.removeListener('data',onData);input.removeListener('end',onEnd);input.removeListener('close',onEnd);input.removeListener('error',onError);output.removeListener('error',onError);
   try{input.setRawMode(wasRaw)}catch{}
   if(!wasFlowing)input.pause();
   try{write('\x1b[?2004l\x1b[?25h\r\n')}catch{}
  }
  function fail(error){if(settled)return;settled=true;account=[];password=[];pasted='';cleanup();reject(error)}
  function cancel(){fail(inputError('AUTH_INPUT_CANCELLED','已取消本机凭据输入，未提交登录。'))}
  function onEnd(){fail(inputError('AUTH_INPUT_INCOMPLETE','终端输入已结束，未提交不完整的凭据。'))}
  function onError(){fail(inputError('AUTH_INPUT_IO','终端输入不可用，未提交登录。'))}
  function redrawAccount(){write('\r\x1b[2K禅道账号：'+account.join(''))}
  function append(character){
   if(complete)throw inputError('AUTH_INPUT_MULTILINE','检测到多行凭据输入，请分别输入账号与密码；未提交登录。');
   const line=stage==='account'?account:password;line.push(character);
   if(line.join('').length>(stage==='account'?256:4096))throw inputError('AUTH_INPUT_TOO_LONG','终端凭据输入过长，未提交登录。');
   if(stage==='account')write(character);
  }
  function enter(){
   if(complete)throw inputError('AUTH_INPUT_MULTILINE','检测到多行密码输入，请粘贴单行密码后按回车；未提交登录。');
   if(stage==='account'){
    if(!account.join('').trim())throw inputError('AUTH_ACCOUNT_EMPTY','账号不能为空，请重新运行本机登录。');
    // Change phase synchronously before consuming the rest of this same data chunk.
    stage='password';write('\r\n禅道密码：');
   }else{
    if(!password.length)throw inputError('AUTH_PASSWORD_EMPTY','密码不能为空，请重新运行本机登录。');
    complete=true;
   }
  }
  function consume(character){
   if(settled)return;
   if(character==='\x03'||character==='\x04'){cancel();return}
   if(escape){
    escape+=character;
    if(escape===PASTE_START){if(paste||complete)throw inputError('AUTH_INPUT_CONTROL','不支持嵌套或提交后的粘贴控制序列，未提交登录。');paste=true;pasted='';escape='';return}
    if(escape===PASTE_END){if(!paste)throw inputError('AUTH_INPUT_CONTROL','粘贴控制序列不完整，未提交登录。');paste=false;escape='';for(const value of pasted)append(value);pasted='';return}
    if(!PASTE_START.startsWith(escape)&&!PASTE_END.startsWith(escape))throw inputError('AUTH_INPUT_CONTROL','不支持该终端控制序列，请重新输入凭据；未提交登录。');
    return;
   }
   if(character==='\x1b'){escape=character;return}
   if(paste){
    if(character==='\r'||character==='\n')throw inputError('AUTH_INPUT_MULTILINE','粘贴内容包含换行，请只粘贴单行账号或密码；未提交登录。');
    if(/[\u0000-\u001f\u007f]/u.test(character))throw inputError('AUTH_INPUT_CONTROL','粘贴内容包含控制字符，未提交登录。');
    pasted+=character;if(pasted.length>4096)throw inputError('AUTH_INPUT_TOO_LONG','粘贴内容过长，未提交登录。');return;
   }
   if(character==='\n'&&skipLF){skipLF=false;return}
   skipLF=false;
   if(character==='\r'||character==='\n'){enter();skipLF=character==='\r';return}
   if(character==='\x7f'||character==='\b'){
    if(complete)throw inputError('AUTH_INPUT_MULTILINE','提交后仍有编辑输入，请重新输入凭据；未提交登录。');
    (stage==='account'?account:password).pop();if(stage==='account')redrawAccount();return;
   }
   if(/[\u0000-\u001f\u007f]/u.test(character))throw inputError('AUTH_INPUT_CONTROL','终端输入包含不支持的控制字符，未提交登录。');
   append(character);
  }
  function scheduleCommit(){
   if(!complete||settled||commit)return;
   // Do not send a first line while the same read batch still contains more paste data.
   commit=setImmediate(()=>{
    commit=null;if(settled)return;
    if(escape||paste){fail(inputError('AUTH_INPUT_INCOMPLETE','终端控制序列或粘贴未完成，未提交登录。'));return}
    try{validator.decode();if(decoder.end())throw Error('unfinished UTF-8')}
    catch{fail(inputError('AUTH_INPUT_ENCODING','终端输入存在未完成的 UTF-8 字节，未提交登录。'));return}
    settled=true;const credentials={account:account.join(''),password:password.join('')};account=[];password=[];cleanup();resolve(credentials);
   });
  }
  function onData(value){
   if(settled)return;
   try{
    const bytes=Buffer.isBuffer(value)?value:Buffer.from(value,'utf8');
    // StringDecoder preserves split code points; fatal validation prevents silent replacement.
    validator.decode(bytes,{stream:true});
    for(const character of decoder.write(bytes)){consume(character);if(settled)break}
    scheduleCommit();
   }catch(error){fail(error.code?error:inputError('AUTH_INPUT_ENCODING','终端输入不是完整 UTF-8，未提交登录。'))}
  }
  input.on('data',onData);input.once('end',onEnd);input.once('close',onEnd);input.once('error',onError);output.once('error',onError);
  try{input.setRawMode(true);write('\x1b[?2004h禅道账号：');input.resume()}catch{onError()}
 });
}
