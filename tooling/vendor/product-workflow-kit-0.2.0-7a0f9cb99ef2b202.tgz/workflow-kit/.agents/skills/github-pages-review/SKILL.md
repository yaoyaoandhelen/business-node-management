---
name: github-pages-review
description: 为指定业务项目生成原型与需求统一评审快照、保留历史版本，并发布或验证该项目自己的GitHub Pages站点。用于原型评审交付，不用于通用网站托管迁移。
---

先读 [Agent 协议](../../../docs/agent-protocol.md)、[工作流](../../../docs/workflow.md)、[发布说明](../../../docs/publication.md) 和 [手册](../../../docs/user-guide.md)。文件入口不依赖客户端原生注册。

读取项目规则、配置、工具锁、当前来源、需求校验、归档及实际评审决定。0.2 支持时用 `workflow context --intent review` 或 `--intent publish`；发现缺失/冲突证据先处理，不把历史 URL 当作当前在线。仓库、分支和 Pages 地址按项目配置，不选全局默认仓库。

根据用户目标选择动作，不能把下面命令当成必须全部执行的流水线：

```sh
node tooling/run.mjs review preview --project project.config.yaml
node tooling/run.mjs review freeze --project project.config.yaml --change CHANGE_ID
node tooling/run.mjs review export --project project.config.yaml
```

preview 允许未提交来源；正式 freeze 要求本业务独立仓库中登记输入已提交，manifest 同时绑定需求、源码和工具。保存成功后冻结共同版本，重试复用同一身份。批准必须有明确实际决定，独立引用快照，不替评审者同意；新改动不继承旧批准或实施结论。

先完成完整静态包与本机验证，关闭开发服务后检查默认完整设计、需求空间、页面及根/仓库子路径资源。组装全部保留历史快照，旧链接和内容不变。团队交付只有一个统一可达入口，localhost 只供本机。

按现有授权配置或发布本项目；未指定目标时保留本地产物、准确报告缺项。业务通常使用已有锁定归档，只有明确升级工具才重新 bundle，不为普通发布静默替换锁。新能力和旧 0.1 兼容引导器的边界见手册。

准备、dispatch、部署和回读分别记录。只有取得实际 URL 并核对指定 reviewId、manifest hash 和关键资源后报告上线；错误版本、缓存旧包或资源不符判验证失败。记录实际证据及跨会话交接，不把 CI 成功、HTTP 200 或静态导出替代线上验证。
