# 产品设计工作流工具箱

从需求分析开始，完成 HTML 原型、在线展示、评审优化、禅道交接和研发协同。验收条件现在维护，完整产品验收阶段保留。

## 运行现有示例

在本工具箱目录运行：

```sh
npm ci
npm run check
npm run demo
```

统一本机入口：<http://127.0.0.1:5184/>。默认展示完整原型，右下角进入功能需求；切换空间保留当前 iframe 状态。需求在业务项目 `data/requirements/workflow-demo.json` 持久化。页面数据均为模拟数据。

这是本机预览地址。团队在线展示需将业务项目发布到该项目自己的 GitHub Pages 地址。

## 创建另一个业务项目

```sh
node bin/pwf.mjs project init --directory ../projects/my-product --id my-product --name 我的产品
npm install --prefix ../projects/my-product/prototype
node bin/pwf.mjs project check --project ../projects/my-product/project.config.yaml
```

首次生成原型尚无 package-lock 时，用 `npm install --prefix ../projects/my-product/prototype` 创建锁文件，此后使用 `npm ci`。多个项目同时运行时，在各项目 `.local/project.local.yaml` 登记不同空闲端口；不会静默切换或选择示例项目。

每个业务项目独立保存规格、原型、评审归档和交接映射，也独立配置自己的 GitHub 仓库与站点地址。工具箱不将工作空间根或个人资料纳入 Git 仓库。

## 产品工作流程

在业务项目根，可使用 `node tooling/run.mjs` 调用锁定工具版本：

| 工作 | 命令 |
| --- | --- |
| 查看阶段与外部缺项 | `node tooling/run.mjs workflow status --project project.config.yaml` |
| 校验需求 | `node tooling/run.mjs requirements validate --project project.config.yaml` |
| 生成 OpenSpec 规格视图 | `node tooling/run.mjs requirements project --project project.config.yaml` |
| 启动原型与需求工作台 | `node tooling/run.mjs studio dev --project project.config.yaml` |
| 生成本地预览快照 | `node tooling/run.mjs review preview --project project.config.yaml` |
| 冻结正式评审 | `node tooling/run.mjs review freeze --project project.config.yaml` |
| 导出完整静态站点 | `node tooling/run.mjs review export --project project.config.yaml` |
| 禅道草案预演 | `node tooling/run.mjs zentao plan --project project.config.yaml --draft` |

需求规则只编辑项目 JSON，按模块和子模块组织；字段说明和统计口径集中在所属模块。OpenSpec 投影检测外部修改并报告冲突，不把另一份文本静默回写为规则源。

正式评审要求业务源码和需求已在其独立 Git 仓库提交。批准通过 `review approve --review <ID> --actor <实际记录人> --decision approved` 显式记录；本地预览不能充当正式批准。工具不会替评审者或项目经理确认。

详细接入见 [Studio](docs/studio.md)、[Pages](docs/publication.md)、[禅道](docs/zentao.md)。

## Pages 配置与历史版本

各项目 `project.config.yaml` 的 `github` 保存 owner、repository、branch、basePath 和最终站点 URL。没有全局单一仓库。

```sh
node tooling/run.mjs pages configure --project project.config.yaml
node tooling/run.mjs toolkit bundle --project project.config.yaml
node tooling/run.mjs review export --project project.config.yaml
```

提交该项目的配置、原型/需求源码、正式 `site-archive/`、评审记录、`.github/workflows/pages.yml`、`tooling/restore.mjs` 和锁定工具归档到本项目仓库，启用 Pages 的 GitHub Actions 发布。恢复脚本校验归档摘要，在干净 CI 中安装同一工具版本。

站点默认入口进入当前预览；`review/<reviewId>/` 固定指向正式版本。每次部署组装所有保留版本，禁止覆盖历史快照。部署后核对实际 URL、目标 manifest 和关键资源，成功后才记录已上线。

## 禅道接入

默认使用 MCP。项目中保存实例与产品/项目/执行/接收人映射；MCP 地址、认证文件等本机覆盖可放 `.local/project.local.yaml`。先运行 `zentao mcp-discover` 获取实际工具 schema，再配置交接映射；不通过页面操作禅道。令牌通过本地隐藏输入换取或 `ZENTAO_TOKEN` 提供，不写入业务源码或聊天。

正式交接引用批准版本；默认先产生可核对计划，`sync --execute` 才执行已授权写入。重复执行复用稳定映射，超时先核对；负责人、排期、工时和状态由禅道维护。研发变更先生成影响清单，再记录范围和执行影响决定。

## 验证

```sh
npm test
node scripts/verify-demo.mjs
```

`npm test` 验证配置隔离、JSON往返、规格投影、冻结/归档、Pages版本核对、禅道超时恢复和协同状态。真实浏览器测试使用系统 Chrome；缺浏览器时会明确跳过。`verify-demo` 使用示例登记端口启动并检查需求编辑、真实落盘、刷新恢复和模式隔离；如示例服务已启动则加 `--existing`。

共享 Skill 位于 `.agents/skills`。安装到项目的入口指向共享源码并保留版本信息，不覆盖已有同名 Skill 或修改用户全局配置。
