<script setup>
import {computed,nextTick,watch} from 'vue'
const props=defineProps({node:Object,requirements:Object,activeReqId:String,readonly:Boolean})
const emit=defineEmits(['edit','locate'])
const sections=computed(()=>props.node?[...(props.node.reqIds?.length?[props.node]:[]),...(props.node.children||[])]:[])
const records=s=>(s.reqIds||[]).map(id=>props.requirements[id]).filter(Boolean)
const isField=r=>r.kind==='field'||(!r.kind&&r.reqId.includes('.field.'))
const fields=s=>records(s).filter(isField),functions=s=>records(s).filter(r=>!isField(r))
const scenarios=r=>[...(r.scenarios||[]).map(s=>({...s,category:'业务场景'})),...(r.acceptanceCriteria||[]).map(s=>({...s,category:'验收场景'}))]
watch(()=>[props.activeReqId,props.node?.id],async()=>{await nextTick();if(props.activeReqId)document.getElementById('detail-'+props.activeReqId)?.scrollIntoView({block:'nearest',behavior:'smooth'})},{flush:'post'})
</script>
<template><div v-if="node" class="module-content"><div class="module-intro"><span class="eyebrow">FUNCTION REQUIREMENTS</span><h1>{{node.name}}</h1><p>{{node.description}}</p><span class="module-kind">{{node.children?.length?'模块总览':'交互与规则说明'}}</span></div>
<section v-for="section in sections" :key="section.id" class="detail-section"><header v-if="node.children?.length" class="section-heading"><h2>{{section.name}}</h2><p>{{section.description}}</p></header>
<article v-for="r in functions(section)" :id="'detail-'+r.reqId" :key="r.reqId" :class="['function-detail',{selected:activeReqId===r.reqId}]"><header><h3>{{r.featureName}}</h3><div class="detail-actions"><button @click="emit('locate',r.reqId)">定位</button><button v-if="!readonly" @click="emit('edit',r.reqId)">编辑</button></div></header>
<div v-for="[key,label] in [['interactionSteps','交互流程'],['businessRules','业务规则'],['permissions','权限要求'],['exceptionHandling','异常处理']]" :key="key" v-show="r[key]?.length" class="detail-block"><h4>{{label}}</h4><ol><li v-for="(item,i) in r[key]" :key="i">{{item}}</li></ol></div>
<div v-if="r.fields?.length" class="detail-block"><h4>功能字段</h4><table><thead><tr><th>名称 / 类型</th><th>默认 / 必填</th><th>校验及提示</th></tr></thead><tbody><tr v-for="(f,i) in r.fields" :key="i"><td>{{f.name}} · {{f.type}}</td><td>{{JSON.stringify(f.defaultValue)}} · {{f.required?'必填':'选填'}}</td><td>{{f.validation}}<small>{{f.message}}</small></td></tr></tbody></table></div>
<div v-for="(s,i) in r.statistics||[]" :key="'stats'+i" class="detail-block"><h4>统计口径 · {{s.name}}</h4><p>计算：{{s.formula}}</p><p>范围：{{s.scope}}</p><p>刷新：{{s.refresh}}</p></div>
<div v-for="(s,i) in scenarios(r)" :key="'scenario'+i" class="detail-block"><h4>{{s.category}} · {{s.name}}</h4><p>前置：{{s.given}}</p><p>操作：{{s.when}}</p><ul><li v-for="(t,j) in s.then" :key="j">{{t}}</li></ul></div>
<div v-if="r.fieldValidations?.length" class="detail-block"><h4>补充字段校验</h4><p v-for="(v,i) in r.fieldValidations" :key="i">{{v.field}} · {{v.rule}}<small>{{v.message}}</small></p></div></article>
<div v-if="fields(section).length" class="field-specification"><div class="field-spec-heading"><h3>字段说明与校验</h3><span>归属于{{section.name}}</span></div><table><thead><tr><th>字段</th><th>类型、默认值、必填及校验</th></tr></thead><tbody><tr v-for="r in fields(section)" :id="'detail-'+r.reqId" :key="r.reqId" :class="{selected:activeReqId===r.reqId}"><td><strong>{{r.featureName}}</strong><div class="detail-actions"><button @click="emit('locate',r.reqId)">定位</button><button v-if="!readonly" @click="emit('edit',r.reqId)">编辑</button></div></td><td><p v-for="(f,i) in r.fields||[]" :key="i"><b>{{f.name}}</b> · {{f.type}} · 默认 {{JSON.stringify(f.defaultValue)}} · {{f.required?'必填':'选填'}}<br/>校验：{{f.validation||'无额外校验'}}<small>{{f.message}}</small></p><ul><li v-for="(rule,i) in r.businessRules||[]" :key="i">{{rule}}</li></ul><p v-for="(v,i) in r.fieldValidations||[]" :key="i">{{v.rule}}<small>{{v.message}}</small></p><p v-for="(rule,i) in r.exceptionHandling||[]" :key="i">异常：{{rule}}</p></td></tr></tbody></table></div>
</section><div v-if="!sections.length" class="module-empty">此模块暂无需求说明。</div></div><div v-else class="module-empty">选择模块查看说明。</div></template>
