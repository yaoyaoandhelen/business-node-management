/** A frozen review carries its own UI. Preview is assembled with the same shape. */
export function reviewPath(pathname){return pathname.match(/^(\/(?:[^/?#]+\/)*review\/[a-zA-Z0-9-]+\/)/)?.[1]||pathname.match(/^(\/(?:[^/?#]+\/)*preview\/)/)?.[1]||null}
